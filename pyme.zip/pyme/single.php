<?php

/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Pyme
 */

get_header();
?>
<?php
while (have_posts()) :
    the_post();
    $post_img_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
?>
    <div class="title-container text-center primary-color">
        <h1><?php the_title(); ?></h1>
        <nav>
            <b>
                <a href="<?php echo esc_url(get_home_url()); ?>" class="primary-color"><?php esc_html_e('Inicio', 'pyme'); ?></a>/&nbsp;
                <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>" class="primary-color"><?php esc_html_e('Blog', 'pyme'); ?></a>/&nbsp;
                <?php the_title(); ?>
            </b>
        </nav>
    </div>
    <section class="sinlge-post">
        <div class="container mt-5 mb-5">
            <div class="post-image-container">
                <img src="<?php echo esc_url($post_img_url) ?>" class="img-fluid" alt="post main image">
            </div>

            <?php
            get_template_part('template-parts/content', 'single');
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif; ?>
        </div>
    </section>
<?php
endwhile;
?>

<?php get_footer(); ?>