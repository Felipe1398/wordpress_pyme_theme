<?php

/**
 * Pyme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package FG Fancy Lab
 */

/**
 * Register TGM for required plugins
 */
function pyme_register_tgm()
{
    require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';
    require_once get_template_directory() . '/inc/required-plugins.php';
}
add_action('after_setup_theme', 'pyme_register_tgm');


/**
 * Register customizer
 */
function pyme_register_customizer()
{
    require_once get_template_directory() . '/inc/customizer.php';
}
add_action('after_setup_theme', 'pyme_register_customizer');


/**
 * Register custom navigation based on bootstrap
 */
function pyme_register_navwalker()
{
    require_once get_template_directory() . '/inc/bootstrap_5_wp_nav_menu_walker.php';
}
add_action('after_setup_theme', 'pyme_register_navwalker');


/**
 * Enqueue scripts and styles.
 */
function pyme_scripts()
{

    // Theme's main stylesheet
    wp_enqueue_style('pyme-style', get_stylesheet_uri(), array(), '1.0', 'all');

    // Bootstrap javascript and CSS files
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js', array('jquery'), '5.1.3', true);
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css', '5.1.3', 'all');


    // Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Bodoni+Moda:opsz@6..96&family=Libre+Franklin:wght@400;800&display=swap');

    // Animate CSS
    $animations_enable = get_theme_mod('set_animations_enable', true);
    $mobile_animations_enable = get_theme_mod('set_mobile_animations_enable', true);
    if ((!wp_is_mobile() && $animations_enable) || (wp_is_mobile() && $mobile_animations_enable)) {
        wp_enqueue_style('animate-css', get_template_directory_uri() . '/inc/css/animate.min.css', '4.1.1', 'all');
        wp_enqueue_script('viewportchecker-js', get_template_directory_uri() . '/inc/js/jquery.viewportchecker.min.js', array('jquery'), '1.8.8', true);
        wp_enqueue_script('animations-js', get_template_directory_uri() . '/inc/js/animations.js', array('jquery'), '', true);
    }

    // Mansory
    wp_enqueue_script('masonry-js', 'https://cdn.jsdelivr.net/npm/masonry-layout@4.2.2/dist/masonry.pkgd.min.js', array('jquery'), '4.2.2', true);

    // Threaded comment reply styles.
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'pyme_scripts');

/**
 * Theme configurations.
 */
function pyme_config()
{
    // Register theme navigation menus
    register_nav_menus(
        array(
            'pyme_main_menu' => esc_html__('Menú principal', 'pyme'),
            'pyme_footer_menu' => esc_html__('Menú de pie de página', 'pyme')
        )
    );

    // Add text translations
    $textdomain = 'pyme';
    load_theme_textdomain($textdomain, get_stylesheet_directory() . '/languages/');
    load_theme_textdomain($textdomain, get_template_directory() . '/languages/');

    // Add support for features
    add_theme_support('woocommerce', array(
        'thumbnail_image_width' => 255,
        'single_image_width'    => 255,
        'product_grid'             => array(
            'default_rows'    => 10,
            'min_rows'        => 5,
            'max_rows'        => 10,
            'default_columns' => 3,
            'min_columns'     => 3,
            'max_columns'     => 5
        )
    ));
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-carousel');
    add_theme_support('custom-logo', array(
        'flex_height' => true,
        'flex_width' => true
    ));
    add_theme_support('title-tag');
    add_theme_support('automatic-feed-links');



    if (!isset($content_width)) {
        $content_width = 600;
    }
}
add_action('after_setup_theme', 'pyme_config', 0);

/**
 * WooCommerce interface modifications
 */
if (class_exists('WooCommerce')) {
    require get_template_directory() . '/inc/wc-modifications.php';
}

/**
 * Show cart contents / total using ajax
 */
function pyme_woocommerce_header_add_to_cart_fragment($fragments)
{
    global $woocommerce;

    ob_start();

?>
    <span class="items position-absolute top-0 start-100 translate-middle badge rounded-pill primary-color-bg">
        <?php echo esc_html(WC()->cart->get_cart_contents_count()); ?>
        <span class="visually-hidden"><?php esc_html_e('productos añadidos', 'pyme'); ?></span>
    </span>
<?php
    $fragments['span.items'] = ob_get_clean();
    return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'pyme_woocommerce_header_add_to_cart_fragment');

/**
 * Register widgets areas / sidebars
 */
function pyme_sidebars()
{
    register_sidebar(array(
        'name' => esc_html__('Barra lateral principal', 'pyme'),
        'id' => 'pyme-main-sidebar',
        'description' => esc_html__('Arrastra los widgets aquí, estos se mostrarán en la barra lateral de la página "blog"', 'pyme'),
        'before_widget' => '<div id="%1$s" class="primary-color widget widget-wrapper %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="widget-title">',
        'after_title' => '</h4>'
    ));
    register_sidebar(array(
        'name' => esc_html__('Barra lateral de la tienda', 'pyme'),
        'id' => 'pyme-shop-sidebar',
        'description' => esc_html__('Arrastra los widgets aquí, estos se mostrarán en la barra lateral de la página de la tienda', 'pyme'),
        'before_widget' => '<div id="%1$s" class="primary-color widget widget-wrapper %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="widget-title">',
        'after_title' => '</h4>'
    ));
}
add_action('widgets_init', 'pyme_sidebars');

/**
 * Commets modifications
 */
require get_template_directory() . '/inc/comments-helper.php';

/**
 * Add boostrap classes to the pagination
 */
function pyme_bootstrap_pagination(\WP_Query $wp_query = null, $echo = true, $params = [])
{
    if (null === $wp_query) {
        global $wp_query;
    }

    $add_args = [];

    $pages = paginate_links(
        array_merge([
            'base'         => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
            'format'       => '?paged=%#%',
            'current'      => max(1, get_query_var('paged')),
            'total'        => $wp_query->max_num_pages,
            'type'         => 'array',
            'show_all'     => false,
            'end_size'     => 3,
            'mid_size'     => 1,
            'prev_next'    => true,
            'prev_text'    => '« ' . esc_html__('Anterior', 'pyme'),
            'next_text'    => esc_html__('Siguiente', 'pyme') . ' »',
            'add_args'     => $add_args,
            'add_fragment' => ''
        ], $params)
    );

    if (is_array($pages)) {
        $pagination = '<nav aria-label="Navegación de páginas"><ul class="pagination">';

        foreach ($pages as $page) {
            $pagination .= '<li class="page-item' . (strpos($page, 'current') !== false ? ' active' : '') . '"> ' . str_replace('page-numbers', 'page-link', $page) . '</li>';
        }

        $pagination .= '</ul></nav>';

        if ($echo) {
            echo $pagination;
        } else {
            return $pagination;
        }
    }

    return null;
}
