<?php

/**
 * The template for displaying the 404 template in the Twenty Twenty theme.
 *
 * @package Pyme
 */

get_header();
?>

<div class="nothing d-flex justify-content-center">
    <div class="row align-items-center justify-content-center">
        <div class="col-6">
            <svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path class="svg-icon-primary-color" d="M10 2C5.5935666 2 2 5.5935666 2 10C2 14.406433 5.5935666 18 10 18C12.023929 18 13.871701 17.237039 15.283203 15.990234L16 16.707031L16 18L20 22L22 20L18 16L16.707031 16L15.990234 15.283203C17.237039 13.871701 18 12.023929 18 10C18 5.5935666 14.406433 2 10 2 z M 10 4C13.325553 4 16 6.6744469 16 10C16 13.325553 13.325553 16 10 16C6.6744469 16 4 13.325553 4 10C4 6.6744469 6.6744469 4 10 4 z M 7 8 A 1 1 0 0 0 6 9 A 1 1 0 0 0 7 10 A 1 1 0 0 0 8 9 A 1 1 0 0 0 7 8 z M 13 8 A 1 1 0 0 0 12 9 A 1 1 0 0 0 13 10 A 1 1 0 0 0 14 9 A 1 1 0 0 0 13 8 z M 10 10.996094C8.7774131 10.996094 7.5540957 11.364541 6.5195312 12.103516L7.6816406 13.732422C9.0425117 12.760371 10.955535 12.760371 12.316406 13.732422L13.478516 12.103516C12.443951 11.364541 11.222587 10.996094 10 10.996094 z" fill="#FFFFFF" />
            </svg>
        </div>
        <div class="col-6">
            <h2><b><?php esc_html_e('Página no encontrada', 'pyme'); ?>.</b></h2>
            <h5>La página que estás buscando no fué encontrada</h5>
        </div>
        <div class="col-6 mt-5">
            <?php
            the_widget(
                'WP_Widget_Recent_Posts',
                array(
                    'title' => esc_html__('Echa un vistaso a nuestros últimos posts', 'pyme'),
                    'number' => 3
                )
            )
            ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>