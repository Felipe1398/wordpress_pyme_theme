<?php

/**
 * Template part for displaying categories section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */

$cat_args = array(
    'orderby' => 'name',
    'order' => 'asc',
    'hide_empty' => false,
);

$product_categories = get_terms('product_cat', $cat_args);

if (!empty($product_categories)) :
    $categories_title = get_theme_mod('set_categories_title', __('Categorías de productos', 'pyme'));
    $categories_subtitle = get_theme_mod('set_categories_subtitle', __('Visita nuestra tienda y descubre todos nuestros productos', 'pyme'));
    $categories_title_alignment = get_theme_mod('set_categories_title_alignment', 2);
    $categories_subtitle_alignment = get_theme_mod('set_categories_subtitle_alignment', 2);

    $title_alignment = 'text-start';
    $subtitle_alignment = 'text-start';


    if ($categories_title_alignment == '1') :
        $title_alignment = 'text-end';
    elseif ($categories_title_alignment == '2') :
        $title_alignment = 'text-center';
    endif;


    if ($categories_subtitle_alignment == '1') :
        $subtitle_alignment = 'text-end';
    elseif ($categories_subtitle_alignment == '2') :
        $subtitle_alignment = 'text-center';
    endif;

    if (!empty($categories_title)) :
?>
        <section id="categories-section" class="mt-5">
            <div class="card secondary-color-bg py-4">
                <div class="card-body">
                    <h5 class="card-title mb-0 <?php echo esc_attr($title_alignment); ?>"><?php echo esc_html($categories_title); ?></h5>
                    <p class="card-description mb-5 <?php echo esc_attr($subtitle_alignment); ?>"><?php echo esc_html($categories_subtitle); ?></p>
                    <div class="row row-cols-2 row-cols-md-3 mx-auto">
                        <?php
                        for ($i = 0; $i < count($product_categories); $i++) :
                            $categorie_logo = get_theme_mod('set_categorie_logo' . ($i + 1));
                            $categorie_name = $product_categories[$i]->name;
                            $categorie_url = get_term_link($product_categories[$i]);
                            $categorie_visibility = get_theme_mod('set_category_visibility' . ($i + 1), true);

                            if ($categorie_visibility) :
                        ?>
                                <div class="col mt-2">
                                    <div class="card align-middle rounded-3">
                                        <a href="<?php echo esc_url($categorie_url); ?>">
                                            <div class="mt-4 mb-2">
                                                <img width="80px" height="80px" class="mx-auto d-block" src="<?php echo esc_url($categorie_logo); ?>">
                                                <div class="card-body">
                                                    <h5 class="card-title text-center mt-3"><?php echo esc_html($categorie_name); ?></h5>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                        <?php
                            endif;
                        endfor;
                        ?>
                    </div>
                </div>
            </div>
        </section>
<?php
    endif;
endif;
?>