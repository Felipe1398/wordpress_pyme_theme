<?php

/**
 * Template part for displaying popular products section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<section id="popular-products-section" class="mt-5">
    <?php
    $popular_products_title = get_theme_mod('set_popular_products_title', __('Productos populares', 'pyme'));
    $popular_products_subtitle = get_theme_mod('set_popular_products_subtitle', __('Visita nuestra tienda y encuentra más productos como estos', 'pyme'));
    $popular_products_title_alignment = get_theme_mod('set_popular_products_title_alignment', 2);
    $products_subtitle_alignment = get_theme_mod('set_popular_products_subtitle_alignment', 2);
    $num_popular_products = get_theme_mod('set_num_popular_products', 0);

    $title_alignment = 'text-start';
    $subtitle_alignment = 'text-start';

    if ($popular_products_title_alignment == '1') :
        $title_alignment = 'text-end';
    elseif ($popular_products_title_alignment == '2') :
        $title_alignment = 'text-center';
    endif;


    if ($products_subtitle_alignment == '1') :
        $subtitle_alignment = 'text-end';
    elseif ($products_subtitle_alignment == '2') :
        $subtitle_alignment = 'text-center';
    endif;


    if (!empty($num_popular_products)) :

    ?>
        <div class="card secondary-color-bg py-4">
            <div class="card-body">
                <h5 class="card-title mb-0 <?php echo esc_attr($title_alignment); ?>"><?php echo esc_html($popular_products_title); ?></h5>
                <p class="card-description mb-5 <?php echo esc_attr($subtitle_alignment); ?>"><?php echo esc_html($popular_products_subtitle); ?></p>
                <div class="popular-products">
                    <?php echo do_shortcode('[products limit = "' . esc_attr($num_popular_products) . '" columns="4" orderby="popularity"]'); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</section>