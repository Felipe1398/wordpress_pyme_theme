<?php

/**
 * Template part for displaying recent posts section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<?php
$number_posts = get_theme_mod('set_recent_posts_num', 0);
if (have_posts() && $number_posts > 0) : ?>
    <section id="recent-posts-section" class="mt-5">
        <?php
        $recent_posts_title = get_theme_mod('set_recent_posts_title',  __('Artículos recientes', 'pyme'));
        $recent_posts_subtitle = get_theme_mod('set_recent_posts_subtitle', __('Visita nuestro blog y lee más artículos como estos', 'pyme'));
        $recent_posts_title_alignment = get_theme_mod('set_recent_posts_title_alignment', 2);
        $recent_posts_subtitle_alignment = get_theme_mod('set_recent_posts_subtitle_alignment', 2);

        $title_alignment = 'text-start';
        $subtitle_alignment = 'text-start';


        if ($recent_posts_title_alignment == '1') :
            $title_alignment = 'text-end';
        elseif ($recent_posts_title_alignment == '2') :
            $title_alignment = 'text-center';
        endif;


        if ($recent_posts_subtitle_alignment == '1') :
            $subtitle_alignment = 'text-end';
        elseif ($recent_posts_subtitle_alignment == '2') :
            $subtitle_alignment = 'text-center';
        endif;

        $recent_posts = wp_get_recent_posts(array(
            'numberposts' => $number_posts, // Number of recent posts to display
            'post_status' => 'publish' // Show only the published posts
        ));
        ?>
        <div class="card secondary-color-bg py-4">
            <div class="card-body">
                <h5 class="card-title mb-0 <?php echo esc_attr($title_alignment); ?>"><?php echo esc_html($recent_posts_title); ?></h5>
                <p class="card-description mb-5 <?php echo esc_attr($subtitle_alignment); ?>"><?php echo esc_html($recent_posts_subtitle); ?></p>
                <div class="row justify-content-md-center">
                    <div class="col-12 col-md-10">
                        <div class="row gy-3 justify-content-center" data-masonry='{"percentPosition": true }'>
                            <?php
                            for ($i = 0; $i < sizeof($recent_posts); $i++) :
                                $post_img_url = get_the_post_thumbnail_url($recent_posts[$i]['ID'], 'full');
                            ?>

                                <div class="col-12 col-md-4">
                                    <div class="card post-card">
                                        <img class="img-fluid" src="<?php echo esc_url($post_img_url) ?>" class="card-img-top">
                                        <span class="badge position-absolute rounded-0">
                                            <div class="d-flex align-items-center">
                                                <svg class="me-1" width="18px" height="18px" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" viewBox="0 0 24 24" fill="#FFFFFF">
                                                    <path d="M6 1L6 3L5 3C3.9 3 3 3.9 3 5L3 19C3 20.1 3.9 21 5 21L19 21C20.1 21 21 20.1 21 19L21 5C21 3.9 20.1 3 19 3L18 3L18 1L16 1L16 3L8 3L8 1L6 1 z M 5 8L19 8L19 19L5 19L5 8 z M 13 13L13 17L17 17L17 13L13 13 z" fill="#FFFFFF" />
                                                </svg>
                                                <?php echo esc_html(get_the_date('d/m/Y', $recent_posts[$i]['ID'])) ?>
                                            </div>
                                        </span>
                                        <div class="card-body align-middle overflow-hidden">
                                            <h5 class="card-title mt-3"><?php echo esc_html($recent_posts[$i]['post_title']) ?></h5>
                                        </div>
                                        <a href="<?php echo esc_url(get_permalink($recent_posts[$i]['ID'])) ?>" class="btn rounded-0 rounded-bottom"><?php esc_html_e('Leer más', 'pyme'); ?></a>
                                    </div>
                                </div>

                            <?php
                            endfor;
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php endif ?>