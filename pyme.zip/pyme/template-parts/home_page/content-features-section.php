<?php

/**
 * Template part for displaying features section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<section id="features-section" class="mt-5">
    <div class="row row-cols-2 row-cols-md-4">
        <?php
        for ($i = 1; $i <= 4; $i++) :
            $feature_text = get_theme_mod('set_feature_text' . $i);
            $feature_logo = get_theme_mod('set_feature_logo' . $i);
            
            if (!empty($feature_text) && !empty($feature_logo)) :
        ?>
                <div class="col mt-2">
                    <div class="card secondary-color-bg h-100">
                        <img width="80px" height="80px" class="mx-auto mt-3 d-block" src="<?php echo esc_url($feature_logo); ?>">
                        <div class="card-body">
                            <h5 class="card-title text-center"><?php echo esc_html($feature_text); ?></h5>
                        </div>
                    </div>
                </div>
        <?php
            endif;
        endfor;
        ?>
    </div>
</section>