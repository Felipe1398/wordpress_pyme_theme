<?php

/**
 * Template part for displaying about section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>

<section id="about-section" class="mt-5">
    <!-- Modals -->

    <?php for ($i = 1; $i <= get_theme_mod('set_about_num_slides', 0); $i++) :
        $slide_img = get_theme_mod('set_slide_img' . $i);
    ?>
        <div class="modal fade" id="<?php echo 'slideImgModal' . esc_attr($i) ?>" tabindex="-1" aria-labelledby="<?php echo 'slideImgModal' . esc_attr($i) ?>Label" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn-close mt-1 me-1" data-bs-dismiss="modal" aria-label="<?php esc_attr_e('Close', 'pyme') ?>"></button>
                    </div>
                    <div class="modal-body">
                        <img src="<?php echo esc_url($slide_img); ?>" class="rounded w-100 h-100">
                    </div>
                </div>
            </div>
        </div>
    <?php endfor ?>

    <?php
    $about_title = get_theme_mod('set_about_title', __('Ingrese el título de la sección', 'pyme'));
    $about_subtitle = get_theme_mod('set_about_subtitle', __('¿Quienes somos?', 'pyme'));
    $about_description = get_theme_mod('set_about_description');
    $about_title_alignment = get_theme_mod('set_about_title_alignment', 2);
    $about_subtitle_alignment = get_theme_mod('set_about_subtitle_alignment', 2);
    $about_description_alignment = get_theme_mod('set_about_description_alignment', 3);

    $title_alignment = 'text-start';
    $subtitle_alignment = 'text-start';
    $description_alignment = 'text-start';


    if ($about_title_alignment == '1') :
        $title_alignment = 'text-end';
    elseif ($about_title_alignment == '2') :
        $title_alignment = 'text-center';
    endif;

    if ($about_subtitle_alignment == '1') :
        $subtitle_alignment = 'text-end';
    elseif ($about_subtitle_alignment == '2') :
        $subtitle_alignment = 'text-center';
    endif;

    if ($about_description_alignment == '1') :
        $description_alignment = 'text-end';
    elseif ($about_description_alignment == '2') :
        $description_alignment = 'text-center';
    elseif ($about_description_alignment == '3') :
        $description_alignment = 'text-justify';
    endif;

    ?>
    <div class="card secondary-color-bg py-4">
        <div class="card-body">
            <h5 class="card-title mb-0 <?php echo esc_attr($title_alignment); ?>"><?php echo esc_html($about_title); ?></h5>
            <p class="card-description mb-5 <?php echo esc_attr($subtitle_alignment); ?>"><?php echo esc_html($about_subtitle); ?></p>
            <div class="description">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <p class="<?php echo esc_html($description_alignment); ?>">
                            <?php echo esc_html($about_description) ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php
            if (get_theme_mod('set_about_num_slides', 0) > 0) : ?>
                <div id="carousel2" class="carousel slide mt-5 w-100" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php
                        $i = 1;
                        while ($i <= get_theme_mod('set_about_num_slides', 0)) : ?>
                            <div class="carousel-item <?php if ($i == 1) {
                                                            echo 'active';
                                                        } ?>">
                                <div class="row justify-content-center gx-2">
                                    <?php
                                    $j = 0;
                                    if (wp_is_mobile()) {
                                        $n = 1;
                                    } else {
                                        $n = 3;
                                    }
                                    while ($j < $n && $i <= get_theme_mod('set_about_num_slides', 0)) :
                                        $slide_img = get_theme_mod('set_slide_img' . $i);
                                    ?>
                                        <div id="about-section-slide-img-container" class="col-9 col-sm-7 col-lg-3" data-bs-toggle="modal" data-bs-target="<?php echo '#slideImgModal' . esc_attr($i) ?>">
                                            <img src="<?php echo esc_url($slide_img); ?>" class="rounded w-100 h-100">
                                        </div>
                                    <?php
                                        $j++;
                                        $i++;
                                    endwhile;
                                    ?>
                                </div>
                            </div>
                        <?php
                        endwhile;
                        ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carousel2" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden"><?php esc_html_e('Anterior', 'pyme'); ?></span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carousel2" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden"><?php esc_html_e('Siguiente', 'pyme'); ?></span>
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>