<?php

/**
 * Template part for displaying main carousel
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<section id="main-carousel-section" class="secondary-color-bg">
    <div id="carousel1" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <?php for ($i = 0; $i < get_theme_mod('set_num_slides', 0); $i++) : ?>
                <button type="button" data-bs-target="#carousel1" data-bs-slide-to="<?php echo esc_attr($i) ?>" <?php if ($i == 0) {
                                                                                                                    echo 'class="active primary-color-bg" aria-current="true"';
                                                                                                                } else {
                                                                                                                    echo 'class="primary-color-bg"';
                                                                                                                } ?> aria-label="<?php echo esc_attr_x('Slide', 'slide de un carrusel', 'pyme') . ' ' . esc_attr($i + 1) ?>"></button>
            <?php endfor; ?>
        </div>
        <div class="carousel-inner">
            <?php
            $num_slides = get_theme_mod('set_num_slides', 0);
            // Getting data from Customizer to display the Carousel section
            for ($i = 1; $i <= $num_slides; $i++) :
                $carousel_page[$i] = get_theme_mod('set_carousel_page' . $i);
                $carousel_button_text[$i] = get_theme_mod('set_carousel_button_text' . $i, __('Comprar ahora', 'pyme'));
                $carousel_button_url[$i] = get_theme_mod('set_carousel_button_url' . $i, 'https://www.google.com/');
                $carousel_button_visibility[$i] = get_theme_mod('set_carousel_button_visibility' . $i, true);
                $carousel_position[$i] = get_theme_mod('set_carousel_position' . $i, 0);
                $carousel_title_alignment[$i] = get_theme_mod('set_carousel_title_alignment' . $i, 2);
                $carousel_subtitle_alignment[$i] = get_theme_mod('set_carousel_subtitle_alignment' . $i, 2);
                $carousel_button_alignment[$i] = get_theme_mod('set_carousel_button_alignment' . $i, 2);

                if ($carousel_position[$i] == '1') :
                    $image_position[$i] = 'order-2 justify-content-start';
                    $text_position[$i] = 'order-1';
                else :
                    $image_position[$i] = 'justify-content-end';
                endif;

                if ($carousel_title_alignment[$i] == '1') :
                    $title_alignment[$i] = 'text-end';
                elseif ($carousel_title_alignment[$i] == '2') :
                    $title_alignment[$i] = 'text-center';
                endif;

                if ($carousel_subtitle_alignment[$i] == '1') :
                    $subtitle_alignment[$i] = 'text-end';
                elseif ($carousel_subtitle_alignment[$i] == '2') :
                    $subtitle_alignment[$i] = 'text-center';
                endif;

                if ($carousel_button_alignment[$i] == '1') :
                    $button_alignment[$i] = 'text-end';
                elseif ($carousel_button_alignment[$i] == '2') :
                    $button_alignment[$i] = 'text-center';
                endif;

            endfor;

            $args = array(
                'post_type' => 'page',
                'posts_per_page' => 3,
                'post__in' => $carousel_page,
                'orderby' => 'post__in'
            );

            $carousel_loop = new WP_Query($args);
            $j = 1;
            if ($carousel_loop->have_posts()) :
                while ($carousel_loop->have_posts()) :
                    $carousel_loop->the_post();
            ?>

                    <div class="carousel-item <?php if ($j == 1) {
                                                    echo 'active';
                                                } ?>">
                        <?php if ($carousel_position[$j] != '2') : ?>
                            <div class="row h-100 justify-content-center">
                                <div class="carousel-img col-6 align-self-center d-flex <?php echo esc_attr($image_position[$j]); ?>">
                                    <?php the_post_thumbnail('pyme_carousel_img_size', array('class' => 'img-fluid')); ?>
                                </div>
                                <div class="col-6 align-self-center px-5 <?php echo esc_attr($text_position[$j]); ?>">
                                    <div class="carousel-title <?php echo 'carousel-title-' . esc_attr($j) . ' ' . esc_attr($title_alignment[$j]); ?>">
                                        <h1 class="secondary-font"><?php the_title(); ?></h1>
                                    </div>
                                    <div class="carousel-description">
                                        <div class="carousel-subtitle <?php echo 'carousel-subtitle-' . esc_attr($j) . ' ' . esc_attr($subtitle_alignment[$j]); ?>"><?php the_content(); ?></div>
                                        <?php if ($carousel_button_visibility[$j]) : ?>
                                            <div class="carousel-btn <?php echo 'carousel-btn-' . esc_attr($j) . ' ' . esc_attr($button_alignment[$j]); ?>">
                                                <a class="btn" role="button" href="<?php echo esc_url($carousel_button_url[$j]); ?>"><?php echo esc_html($carousel_button_text[$j]); ?></a>
                                            </div>
                                        <?php endif ?>
                                    </div>
                                </div>
                            </div>
                        <?php elseif ($carousel_position[$j] == '2') : ?>
                            <div class="position-relative h-100">
                                <?php the_post_thumbnail('pyme_carousel_img_bg_size', array('class' => 'img-fluid position-absolute top-50 start-50 translate-middle')); ?>
                                <div class="w-100 position-absolute top-50 start-50 translate-middle">
                                    <div class="row justify-content-center">
                                        <div class="col-6 align-self-center align-self-center">
                                            <div class="carousel-title <?php echo 'carousel-title-' . esc_attr($j) . ' ' . esc_attr($title_alignment[$j]); ?>">
                                                <h1 class="secondary-font"><?php the_title(); ?></h1>
                                            </div>
                                            <div class="carousel-description">
                                                <div class="carousel-subtitle <?php echo 'carousel-subtitle-' . esc_attr($j) . ' ' . esc_attr($subtitle_alignment[$j]); ?>"><?php the_content(); ?></div>
                                                <?php if ($carousel_button_visibility[$j]) : ?>
                                                    <div class="carousel-btn <?php echo 'carousel-btn-' . esc_attr($j) . ' ' . esc_attr($button_alignment[$j]); ?>">
                                                        <a class="btn" role="button" href="<?php echo esc_url($carousel_button_url[$j]); ?>"><?php echo esc_html($carousel_button_text[$j]); ?></a>
                                                    </div>
                                                <?php endif ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif ?>
                    </div>
            <?php
                    $j++;
                endwhile;
                wp_reset_postdata();
            endif;
            ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carousel1" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?php esc_html_e('Anterior', 'pyme'); ?></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carousel1" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?php esc_html_e('Siguiente', 'pyme'); ?></span>
        </button>
    </div>
</section>