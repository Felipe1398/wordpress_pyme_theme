<?php

/**
 * Template part for displaying about team section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<section id="about-team-section">
    <?php
    $section_title = get_theme_mod('set_about_team_section_title', __('Conoce nuestro equipo', 'pyme'));
    $section_subtitle = get_theme_mod('set_about_team_section_subtitle', __('Conoce nuestro equipo', 'pyme'));

    for ($i = 1; $i <= get_theme_mod('set_num_team_members', 0); $i++) :
        $member_name = get_theme_mod('set_member_name' . $i);
        $member_photo = get_theme_mod('set_member_photo' . $i);
        $member_bio = get_theme_mod('set_member_bio' . $i);
    ?>
        <div class="modal fade" id="<?php echo "member-bio-modal-" . esc_attr($i); ?>" tabindex="-1" aria-labelledby="<?php echo "ModalLabel" . esc_attr($i); ?>" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header primary-color">
                        <h5 class="modal-title text-center" id="<?php echo "ModalLabel" . esc_attr($i); ?>"><b><?php echo esc_html($member_name); ?></b></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php esc_attr_e('Close', 'pyme'); ?>"></button>
                    </div>
                    <div class="modal-body p-5">
                        <p class="text-justify">
                            <?php echo esc_html($member_bio); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    <?php
    endfor;
    ?>

    <div class="card secondary-color-bg py-4">
        <div class="card-body">
            <h5 class="card-title text-center"><?php echo esc_html($section_title); ?></h5>
            <p class="card-description mb-5 text-center"><?php echo esc_html($section_subtitle); ?></p>
            <div id="team-carousel" class="carousel slide mt-5" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php
                    $i = 1;
                    while ($i <= get_theme_mod('set_num_team_members', 0)) :
                    ?>
                        <div class="carousel-item <?php echo $i == 1 ? "active" : ""; ?>">
                            <div class="row justify-content-center">
                                <?php
                                $j = 0;
                                if (wp_is_mobile()) {
                                    $n = 1;
                                } else {
                                    $n = 3;
                                }
                                while ($j < $n && $i <= get_theme_mod('set_num_team_members', 0)) :
                                    $member_name = get_theme_mod('set_member_name' . $i);
                                    $member_photo = get_theme_mod('set_member_photo' . $i);
                                    $member_bio = get_theme_mod('set_member_bio' . $i);
                                ?>
                                    <div class="col-9 col-sm-6 col-lg-3">
                                        <div class="card member-card">
                                            <img src="<?php echo esc_url($member_photo); ?>" class="card-img-top" alt="<?php esc_attr_e('Fotografía del colaborador', 'pyme') ?>">
                                            <div class="card-body">
                                                <h5 class="card-title text-truncate text-center">
                                                    <b><?php echo esc_html($member_name); ?></b>
                                                </h5>
                                                <hr>
                                                <p class="card-text">
                                                    <button type="button" class="btn h-100 w-100" data-bs-toggle="modal" data-bs-target="<?php echo "#member-bio-modal-" . esc_attr($i); ?>">
                                                        <?php esc_html_e('Acerca de mí', 'pyme'); ?>
                                                    </button>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                    $j++;
                                    $i++;
                                endwhile;
                                ?>
                            </div>
                        </div>
                    <?php
                    endwhile;
                    ?>
                    <button class="carousel-control-prev" type="button" data-bs-target="#team-carousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden"><?php esc_html_e('Anterior', 'pyme'); ?></span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#team-carousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden"><?php esc_html_e('Siguiente', 'pyme'); ?></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>