<?php

/**
 * Template part for displaying about products section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<section id="about-products-section" class="mt-5">
    <?php
    $section_title = get_theme_mod('set_about_products_section_title', __('Características de nuestros productos', 'pyme'));
    $section_subtitle = get_theme_mod('set_about_products_section_subtitle', __('¿Que hace especiales a nuestros productos?', 'pyme'));
    ?>

    <div class="card secondary-color-bg py-4">
        <div class="card-body">
            <h5 class="card-title text-center"><?php echo esc_html($section_title); ?></h5>
            <p class="card-description mb-5 text-center"><?php echo esc_html($section_subtitle); ?></p>
            <?php
            $num_products_features = get_theme_mod('set_num_products_features', 0);
            for ($i = 1; $i <= $num_products_features; $i++) :
                $product_feature_title = get_theme_mod('set_product_feature_title' . $i);
                $product_feature_logo = get_theme_mod('set_product_feature_logo' . $i);
                $product_feature_description = get_theme_mod('set_product_feature_description' . $i);
                if (!wp_is_mobile()) {
                    $order_logo = ($i % 2 == 0) ? "order-lg-2" : "order-lg-1";
                    $order_descr = ($i % 2 == 0) ? "order-lg-1" : "order-lg-2";
                } else {
                    $order_logo = "order-2 mt-5";
                    $order_descr = "order-1";
                }

            ?>
                <div class="row mt-5">
                    <div class="col-lg-4 col-12 d-flex align-items-center justify-content-center <?php echo esc_attr($order_logo); ?>">
                        <img class="img-fluid rounded" src="<?php echo esc_url($product_feature_logo); ?>" alt="<?php echo esc_attr($product_feature_title); ?>">
                    </div>
                    <div class="col-lg-8 col-12 <?php echo esc_attr($order_descr); ?>">
                        <div class="card border-0 shadow">
                            <div class="card-body">
                                <h3 class="card-title"><b><?php echo esc_html($product_feature_title); ?></b></h3>
                                <hr>
                                <p class="card-text"><?php echo esc_html($product_feature_description); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            endfor;
            ?>
        </div>
    </div>

</section>