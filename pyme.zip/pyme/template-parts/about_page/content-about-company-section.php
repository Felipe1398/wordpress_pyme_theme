<?php

/**
 * Template part for displaying about company section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<section id="about-company-section" class="mt-5">
    <?php
    $section_title = get_theme_mod('set_about_company_section_title', __('Conoce nuestra historia', 'pyme'));
    $section_subtitle = get_theme_mod('set_about_company_section_subtitle',  __('Conoce más sobre nosotras', 'pyme'));
    ?>

    <div class="card secondary-color-bg py-4">
        <div class="card-body">
            <h5 class="card-title text-center"><?php echo esc_html($section_title); ?></h5>
            <p class="card-description mb-5 text-center"><?php echo esc_html($section_subtitle); ?></p>
            <div class="row justify-content-center section-title-container">
                <div class="col-12 col-lg-9">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <?php the_content(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>