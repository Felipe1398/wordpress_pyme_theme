<?php

/**
 * Template part for displaying in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<article>
    <div><?php the_content() ?></div>
</article>