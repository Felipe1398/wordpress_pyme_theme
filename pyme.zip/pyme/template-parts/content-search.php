<?php

/**
 * Template part for displaying search results
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<?php $post_img_url = get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>
<article <?php post_class(); ?>>
    <div class="card">
        <img height="250" src="<?php echo esc_url($post_img_url) ?>" class="card-img-top img-fluid rounded-0">
        <div class="card-body">
            <h5 class="card-title primary-color overflow-hidden"><?php the_title(); ?></h5>
            <div class="meta">
                <p>
                    <?php esc_html_e('Publicado por', 'pyme'); ?> <b><?php the_author_posts_link(); ?></b> - <?php echo esc_html(get_the_date()); ?>
                    <br />
                    <?php if (has_category()) : ?>
                        <?php esc_html_e('Categorias', 'pyme'); ?>: <span><b><?php the_category(' '); ?></b></span>
                    <?php endif; ?>
                    <br />
                    <?php if (has_tag()) : ?>
                        <?php esc_html_e('Etiquetas', 'pyme'); ?>: <span><b><?php the_tags('', ', '); ?></b></span>
                    <?php endif; ?>
                </p>
            </div>
            <div class="excerpt text-justify overflow-hidden"><?php the_excerpt(); ?></div>
        </div>
        <a href="<?php the_permalink(); ?>" class="btn btn-primary primary-color-bg rounded-0"><?php esc_html_e('Leer más', 'pyme'); ?></a>
    </div>
</article>