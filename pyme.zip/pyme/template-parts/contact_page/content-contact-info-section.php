<?php

/**
 * Template part for displaying contact info section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<section id="contact-info-section">
    <?php
    $section_title = get_theme_mod('set_contact_info_title', __('Contactanos', 'pyme'));
    $section_subtitle = get_theme_mod('set_contact_info_subtitle', __('Contactanos para obtener más información', 'pyme'));
    ?>
    <div class="card secondary-color-bg py-4">
        <div class="card-body">
            <h5 class="card-title text-center"><?php echo esc_html($section_title); ?></h5>
            <p class="card-description mb-5 text-center"><?php echo esc_html($section_subtitle); ?></p>
            <div class="card mb-4 shadow">
                <div class="card-body">
                    <?php the_content(); ?>
                </div>
            </div>
        </div>
    </div>

</section>