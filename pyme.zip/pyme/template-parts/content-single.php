<?php

/**
 * Template part for displaying single post
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
?>
<article <?php post_class(); ?>>
    <div class="meta d-flex justify-content-md-end text-md-end">
        <p>
            <?php esc_html_e('Publicado por', 'pyme'); ?> <b><?php the_author_posts_link(); ?></b> - <?php echo esc_html(get_the_date()); ?>
            <br />
            <?php if (has_category()) : ?>
                <?php esc_html_e('Categorias', 'pyme'); ?>: <span><b><?php the_category(' '); ?></b></span>
            <?php endif; ?>
            <br />
            <?php if (has_tag()) : ?>
                <?php esc_html_e('Etiquetas', 'pyme'); ?>: <span><b><?php the_tags('', ', '); ?></b></span>
            <?php endif; ?>
        </p>
    </div>
    <div class="post-content">
        <?php the_content(); ?>
    </div>
    <?php wp_link_pages(array(
        'before' => '<p class="inner-pagination">' . esc_html__('Páginas', 'pyme') . ':',
        'after' => '</p>'
    )) ?>
</article>