<?php

/**
 * The template for the sidebar containing the main widget area
 *
 * @package Pyme
 */
?>
<?php if (is_active_sidebar('pyme-main-sidebar')) : ?>
	<aside class="mb-4 col-12">
		<a data-bs-toggle="offcanvas" href="#offcanvasFilter" role="button" aria-controls="offcanvasFilter">
			<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 24 24" width="35" height="35">
				<path d="M2 5L2 7L22 7L22 5L2 5 z M 2 11L2 13L22 13L22 11L2 11 z M 2 17L2 19L22 19L22 17L2 17 z" fill="#000000" />
			</svg>
		</a>
	</aside>
	<div class="offcanvas offcanvas-start secondary-color-bg" tabindex="-1" id="offcanvasFilter" aria-labelledby="offcanvasFilterLabel">
		<div class="offcanvas-header">
			<h5 id="offcanvasFilterLabel" class="primary-color"><?php _e('Filtrar entradas', 'pyme'); ?></h5>
			<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
		</div>
		<div class="offcanvas-body">
			<?php dynamic_sidebar('pyme-main-sidebar'); ?>
		</div>
	</div>
<?php endif;
