<?php
/* Template Name: Acerca de */
get_header();
?>
<main>
    <?php
    while (have_posts()) : the_post();
    ?>
        <div class="title-container text-center primary-color">
            <h1><?php the_title() ?></h1>
            <nav><b><a href="<?php echo esc_url(get_home_url()); ?>" class="primary-color"><?php esc_html_e('Inicio', 'pyme'); ?></a>&nbsp;/&nbsp;<?php the_title() ?></b></nav>
        </div>

        <div class="container">
            <?php

            if (get_post()->post_content !== '') :
                get_template_part('template-parts/about_page/content', 'about-company-section');
            endif;

            if (get_theme_mod('set_num_team_members', 0) > 0) :
                get_template_part('template-parts/about_page/content', 'about-team-section');
            endif;

            if (get_theme_mod('set_num_products_features', 0) > 0) :
                get_template_part('template-parts/about_page/content', 'about-products-section');
            endif;

            ?>
        </div>

    <?php
    endwhile;
    ?>
</main>

<?php get_footer(); ?>