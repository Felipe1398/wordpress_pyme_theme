<?php
/* Template Name: Contacto */
get_header();
?>
<main>
    <?php
    while (have_posts()) : the_post();
    ?>
        <div class="title-container text-center primary-color">
            <h1><?php the_title() ?></h1>
            <nav><b><a href="<?php echo esc_url(get_home_url()); ?>" class="primary-color"><?php esc_html_e('Inicio', 'pyme'); ?></a>&nbsp;/&nbsp;<?php the_title() ?></b></nav>
        </div>

        <div class="container mb-5">
            <div class="row gy-5 align-items-center">
                <div class="col-12 col-md-6">
                    <?php
                    if (!empty(get_the_content())) :
                        get_template_part('template-parts/contact_page/content', 'contact-info-section');
                    endif;
                    ?>
                </div>
                <div class="col-12 col-md-6">

                    <?php
                    if (
                        !empty(get_theme_mod('set_social_networks_title')) ||
                        !empty(get_theme_mod('set_social_networks_subtitle')) ||
                        !empty(get_theme_mod('set_contact_phone_1')) ||
                        !empty(get_theme_mod('set_contact_phone_2')) ||
                        !empty(get_theme_mod('set_contact_phone_2')) ||
                        !empty(get_theme_mod('set_contact_whatsapp')) ||
                        !empty(get_theme_mod('set_contact_instagram')) ||
                        !empty(get_theme_mod('set_contact_facebook')) ||
                        !empty(get_theme_mod('set_contact_twitter')) ||
                        !empty(get_theme_mod('set_contact_youtube')) ||
                        !empty(get_theme_mod('set_contact_pinterest'))
                    ) :
                        get_template_part('template-parts/contact_page/content', 'social-networks-section');
                    endif;
                    ?>
                </div>
            </div>
        </div>
    <?php
    endwhile;
    ?>
</main>

<?php get_footer(); ?>