<?php

/**
 * The template for displaying comments
 *
 * The area of the page that contains both current comments
 * and the comment form.
 *
 * @package Pyme
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if (post_password_required()) {
	return;
}
$comments_number = get_comments_number();
?>
<section class="comments-section">
	<div class="container my-5 py-5">
		<div class="row d-flex justify-content-center">
			<div class="col-md-12 col-lg-10 col-xl-10">
				<div class="card">
					<div class="ms-3 my-3">
						<?php esc_html_e('Número de comentarios', 'pyme'); ?>: <?php echo esc_html(number_format_i18n($comments_number)) ?>
					</div>

					<?php if (number_format_i18n($comments_number) != 0) : ?>
						<div class="overflow-scroll comments-container">
							<?php if (have_comments()) : ?>

								<?php the_comments_navigation(); ?>


								<?php
								wp_list_comments(array(
									'style'      => 'ol',
									'short_ping' => true,
									'callback' => 'pyme_comments'
								));

								?>


								<?php the_comments_navigation(); ?>

							<?php endif;
							?>
						</div>
					<?php endif; ?>



					<div class="card-footer py-3 border-0" style="background-color: #f8f9fa;">
						<div class="d-flex flex-start w-100">
							<?php
							$user = wp_get_current_user();
							if ($user && comments_open() && get_comments_number() && post_type_supports(get_post_type(), 'comments')) : ?>
								<img class="rounded-circle shadow-1-strong me-3" src="<?php echo esc_url(get_avatar_url($user->ID, $size = '80', $default = 'https://cdn.icon-icons.com/icons2/1378/PNG/512/avatardefault_92824.png')); ?>" alt="avatar" width="40" height="40" />
							<?php endif; ?>
							<div class="form-outline w-100">
								<?php
								// If comments are closed and there are comments, let's leave a little note, shall we?
								if (!comments_open() && get_comments_number() && post_type_supports(get_post_type(), 'comments')) :
								?>
									<p class="no-comments"><?php esc_html_e('Los comentarios están desactivados para este post', 'pyme'); ?>.</p>
								<?php else :
									$comment_args = array(
										'class_submit' => 'btn primary-color-bg submit',
										'comment_field' => '<p class="comment-form-comment"><label for="comment">' . esc_html_x('Comentario', 'sustantivo', 'pyme') . '</label> <textarea id="comment" name="comment" class="form-control" cols="12" rows="6" aria-required="true" required="required"></textarea></p>',
									);
									comment_form($comment_args);
								endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>