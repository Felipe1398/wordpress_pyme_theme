<?php

/**
 * Template for displaying search forms in Pyme
 *
 * @package Pyme
 */
?>

<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
    <span class="screen-reader-text"><?php esc_html_e('Busqueda para', 'pyme'); ?>:</span>
    <div class="input-group main-search">
        <?php if (class_exists('WooCommerce')) : ?>

            <input type="hidden" value="<?php echo is_home() ? 'post' : 'product' ?>" name="post_type" id="post_type" />

        <?php else : ?>

            <input type="hidden" value="post" name="post_type" id="post_type" />

        <?php
        endif;
        ?>
        <input type="search" class="form-control" placeholder="<?php echo class_exists('WooCommerce') ?  (is_home() ? esc_attr_x('Buscar artículo del blog &hellip;', 'placeholder', 'pyme') : esc_attr_x('Buscar producto de la tienda &hellip;', 'placeholder', 'pyme')) : esc_attr_x('Buscar artículo del blog &hellip;', 'placeholder', 'pyme'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
        <span class="input-group-text primary-color-bg">
            <button type="submit" class="search-submit primary-color-bg border-0">
                <svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 24 24" width="25" height="25">
                    <path class="svg-icon-color" d="M9 2C5.1458514 2 2 5.1458514 2 9C2 12.854149 5.1458514 16 9 16C10.747998 16 12.345009 15.348024 13.574219 14.28125L14 14.707031L14 16L20 22L22 20L16 14L14.707031 14L14.28125 13.574219C15.348024 12.345009 16 10.747998 16 9C16 5.1458514 12.854149 2 9 2 z M 9 4C11.773268 4 14 6.2267316 14 9C14 11.773268 11.773268 14 9 14C6.2267316 14 4 11.773268 4 9C4 6.2267316 6.2267316 4 9 4 z" fill="#FFFFFF" />
                </svg>
                <span class="screen-reader-text"><?php echo esc_html_x('Buscar', 'submit button', 'pyme'); ?></span>
            </button>
        </span>
    </div>

    <?php if (class_exists('WooCommerce')) : ?>

        <input type="hidden" value="<?php echo is_home() ? 'post' : 'product' ?>" name="post_type" id="post_type" />

    <?php else : ?>

        <input type="hidden" value="post" name="post_type" id="post_type" />

    <?php
    endif;
    ?>
</form>