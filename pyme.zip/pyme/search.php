<?php

/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Pyme
 */

get_header();
?>

<main>
    <div class="title-container text-center primary-color">
        <h1><?php esc_html_e('Resultados de búsqueda', 'pyme') ?>: “<?php the_search_query(); ?>”</h1>
        <nav>
            <b>
                <a href="<?php echo esc_url(get_home_url()); ?>" class="primary-color"><?php esc_html_e('Inicio', 'pyme'); ?></a>/&nbsp;
                <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>" class="primary-color"><?php esc_html_e('Blog', 'pyme') ?></a>/&nbsp;
                <?php esc_html_e('Resultados de búsqueda', 'pyme') ?>: “<?php the_search_query(); ?>”
            </b>
        </nav>
    </div>
    <section class="posts-list">
        <div class="container mt-5 mb-5">
            <div class="row gy-4" data-masonry='{"percentPosition": true }'>
                <?php
                if (have_posts()) :
                    while (have_posts()) :
                        the_post();
                ?>
                        <div class="col-12 col-md-4">
                            <?php get_template_part('template-parts/content', 'search') ?>
                        </div>

                    <?php
                    endwhile;
                    ?>
                    <div class="pagination-container d-flex justify-content-center">
                        <?php echo pyme_bootstrap_pagination(); ?>
                    </div>
                <?php
                else :
                ?>
                    <div class="nothing d-flex justify-content-center">
                        <div class="row align-items-center">
                            <div class="col-6">
                                <svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path class="svg-icon-primary-color" d="M10 2C5.5935666 2 2 5.5935666 2 10C2 14.406433 5.5935666 18 10 18C12.023929 18 13.871701 17.237039 15.283203 15.990234L16 16.707031L16 18L20 22L22 20L18 16L16.707031 16L15.990234 15.283203C17.237039 13.871701 18 12.023929 18 10C18 5.5935666 14.406433 2 10 2 z M 10 4C13.325553 4 16 6.6744469 16 10C16 13.325553 13.325553 16 10 16C6.6744469 16 4 13.325553 4 10C4 6.6744469 6.6744469 4 10 4 z M 7 8 A 1 1 0 0 0 6 9 A 1 1 0 0 0 7 10 A 1 1 0 0 0 8 9 A 1 1 0 0 0 7 8 z M 13 8 A 1 1 0 0 0 12 9 A 1 1 0 0 0 13 10 A 1 1 0 0 0 14 9 A 1 1 0 0 0 13 8 z M 10 10.996094C8.7774131 10.996094 7.5540957 11.364541 6.5195312 12.103516L7.6816406 13.732422C9.0425117 12.760371 10.955535 12.760371 12.316406 13.732422L13.478516 12.103516C12.443951 11.364541 11.222587 10.996094 10 10.996094 z" fill="#FFFFFF" />
                                </svg>
                            </div>
                            <div class="col-6">
                                <h2><b><?php esc_html_e('No se encontraron resultados', 'pyme') ?>.</b></h2>
                            </div>
                        </div>
                    </div>
                <?php
                endif
                ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>