<?php

/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Pyme
 */

get_header();
?>

<main>


    <?php
    while (have_posts()) : the_post();
    ?>
        <div class="title-container text-center primary-color">
            <h1><?php the_title() ?></h1>
            <nav><b><a href="<?php echo esc_url(get_home_url()); ?>" class="primary-color"><?php esc_html_e('Inicio', 'pyme') ?></a>&nbsp;/&nbsp;<?php the_title() ?></b></nav>
        </div>
        <section class="default-page">
            <div class="container mt-5 mb-5">
                <?php
                get_template_part('template-parts/content', 'page');
                if (comments_open() || get_comments_number()) :
                    comments_template();
                endif; ?>
            </div>
        </section>
    <?php
    endwhile;
    ?>


</main>

<?php get_footer(); ?>