<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package FG Fancy Lab
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="profile" href="https://gmpg.org/xfn/11" />
    <?php wp_head() ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <div class="offcanvas offcanvas-start secondary-color-bg" tabindex="-1" id="offcanvasMainMenu" aria-labelledby="offcanvasMainMenuLabel">
        <div class="offcanvas-header">
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="<?php esc_attr_e('Cerrar', 'pyme') ?>"></button>
        </div>
        <div class="offcanvas-body">

            <div class="main-menu-container secondary-font">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'pyme_main_menu',
                    'container' => false,
                    'menu_class' => '',
                    'fallback_cb' => '__return_false',
                    'items_wrap' => '<ul id="%1$s" class="nav d-block justify-content-center %2$s">%3$s</ul>',
                    'depth' => 3,
                    'walker' => new bootstrap_5_wp_nav_menu_walker()
                ));
                ?>
            </div>

        </div>
    </div>

    <header class="secondary-color-bg">
        <?php $extended_header = get_theme_mod('set_extended_header', true) ?>
        <div class="header-container container pb-5">
            <div class="row align-items-center justify-content-center">
                <div class="logo d-flex justify-content-center <?php echo !$extended_header ? 'col-lg-2 order-lg-1 mb-lg-0 mt-lg-0' : '' ?> col-12 order-3 mb-5 mt-5">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <p class="site-title"><?php bloginfo('title'); ?></p>
                    <?php endif ?>
                </div>
                <div class="<?php echo !$extended_header ? 'col-lg-8 order-lg-2' : 'col-lg-8' ?> col-12 order-4 search-form-container">
                    <?php get_search_form(); ?>
                </div>

                <div class="col-6 order-1 d-lg-none">
                    <a data-bs-toggle="offcanvas" href="#offcanvasMainMenu" role="button" aria-controls="offcanvasMainMenu">
                        <svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 24 24" width="35" height="35">
                            <path class="svg-icon-color" d="M2 5L2 7L22 7L22 5L2 5 z M 2 11L2 13L22 13L22 11L2 11 z M 2 17L2 19L22 19L22 17L2 17 z" fill="#FFFFFF" />
                        </svg>
                    </a>
                </div>

                <?php if (class_exists('WooCommerce')) : ?>
                    <div class="<?php echo !$extended_header ? 'col-lg-2 order-lg-4 mt-lg-0' : 'col-lg-12' ?> col-6 d-flex order-2 mt-3 justify-content-end">
                        <a href="<?php echo esc_url(wc_get_cart_url()); ?>" class="me-4 position-relative">
                            <svg xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" viewBox="0 0 24 24" fill="#FFFFFF" width="35" height="35" aria-label="search icon">
                                <path class="svg-icon-color" d="M4.4160156 1.9960938L1.0039062 2.0136719L1.0136719 4.0136719L3.0839844 4.0039062L6.3789062 11.908203L5.1816406 13.822266C4.3432852 15.161017 5.3626785 17 6.9414062 17L19 17L19 15L6.9414062 15C6.8301342 15 6.8173041 14.978071 6.8769531 14.882812L8.0527344 13L15.521484 13C16.247484 13 16.917531 12.605703 17.269531 11.970703L20.871094 5.484375C21.242094 4.818375 20.760047 4 19.998047 4L5.25 4L4.4160156 1.9960938 z M 7 18 A 2 2 0 0 0 5 20 A 2 2 0 0 0 7 22 A 2 2 0 0 0 9 20 A 2 2 0 0 0 7 18 z M 17 18 A 2 2 0 0 0 15 20 A 2 2 0 0 0 17 22 A 2 2 0 0 0 19 20 A 2 2 0 0 0 17 18 z" fill="#FFFFFF" />
                            </svg>
                            <span class="items position-absolute top-0 start-100 translate-middle badge rounded-pill primary-color-bg">
                                <?php echo esc_html(WC()->cart->get_cart_contents_count()) ?>
                                <span class="visually-hidden"><?php esc_html_e('productos añadidos', 'pyme') ?></span>
                            </span>
                        </a>
                        <div class="dropdown">
                            <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <svg xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" viewBox="0 0 24 24" fill="#FFFFFF" width="35" height="35">
                                    <path class="svg-icon-color" d="M12 3 A 4 4 0 0 0 8 7 A 4 4 0 0 0 12 11 A 4 4 0 0 0 16 7 A 4 4 0 0 0 12 3 z M 8.8105469 14.392578C5.9935469 15.016578 3 16.385 3 18.5L3 21L21 21L21 18.5C21 16.385 18.006453 15.016578 15.189453 14.392578C14.459453 15.363578 13.308 16 12 16C10.692 16 9.5405469 15.363578 8.8105469 14.392578 z" fill="#FFFFFF" />
                                </svg>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="cuenta">
                                <?php if (is_user_logged_in()) : ?>
                                    <li><a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))) ?>" class="dropdown-item"><?php esc_html_e('Mi cuenta', 'pyme'); ?></a></li>
                                    <li><a href="<?php echo esc_url(wp_logout_url(get_permalink(get_option('woocommerce_myaccount_page_id')))) ?>" class="dropdown-item"><?php esc_html_e('Cerrar sesión', 'pyme'); ?></a></li>
                                <?php else : ?>
                                    <li><a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))) ?>" class="dropdown-item"><?php esc_html_e('Iniciar sesión', 'pyme'); ?> / <?php esc_html_e('Registrarse', 'pyme'); ?></a></li>
                                <?php endif ?>
                            </ul>
                        </div>
                    </div>
                <?php endif ?>
            </div>

            <div class="main-menu-container secondary-font d-none d-lg-block">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'pyme_main_menu',
                    'container' => false,
                    'menu_class' => '',
                    'fallback_cb' => '__return_false',
                    'items_wrap' => '<ul id="%1$s" class="nav justify-content-center %2$s">%3$s</ul>',
                    'depth' => 3,
                    'walker' => new bootstrap_5_wp_nav_menu_walker()
                ));
                ?>
            </div>

        </div>
    </header>