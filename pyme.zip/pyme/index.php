<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Pyme
 */

get_header();
?>

<main>
    <div class="title-container text-center primary-color">
        <h1><?php esc_html_e('Blog', 'pyme') ?></h1>
        <nav><b><a href="<?php echo esc_url(get_home_url()); ?>" class="primary-color"><?php esc_html_e('Inicio', 'pyme') ?></a>&nbsp;/&nbsp;<?php esc_html_e('Blog', 'pyme') ?></b></nav>
    </div>
    <section class="posts-list">
        <div class="container mt-5 mb-5">
            <div class="row">

                <?php get_sidebar() ?>

                <div class="col">
                    <div class="row gy-4" data-masonry='{"percentPosition": true }'>
                        <?php
                        if (have_posts()) :
                            while (have_posts()) :
                                the_post();
                        ?>
                                <div class="col-12 col-md-6 col-lg-4">
                                    <?php get_template_part('template-parts/content') ?>
                                </div>

                            <?php
                            endwhile;
                            ?>
                            <div class="pagination-container d-flex justify-content-center">
                                <?php echo pyme_bootstrap_pagination(); ?>
                            </div>
                        <?php
                        else :
                        ?>
                            <div class="nothing d-flex justify-content-center">
                                <h2><?php esc_html_e('Nada que mostrar', 'pyme') ?>.</h2>
                            </div>
                        <?php
                        endif
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>