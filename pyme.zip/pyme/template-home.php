<?php
/*
Template Name: Página de inicio
*/
get_header();
?>

<main>
    <?php
    if (get_theme_mod('set_num_slides', 0) > 0 && get_theme_mod('set_carousel_page1')) :
        get_template_part('template-parts/home_page/content', 'main-carousel-section');
    endif;
    ?>
    <div class="container">
        <?php

        get_template_part('template-parts/home_page/content', 'features-section');

        if (class_exists('WooCommerce')) :
            get_template_part('template-parts/home_page/content', 'popular-products-section');
        endif;

        if (get_theme_mod('set_about_description')) :
            get_template_part('template-parts/home_page/content', 'about-section');
        endif;

        $cat_args = array(
            'orderby' => 'name',
            'order' => 'asc',
            'hide_empty' => false,
        );
        $product_categories = get_terms('product_cat', $cat_args);
        if (class_exists('WooCommerce') && sizeof($product_categories) > 0) :
            get_template_part('template-parts/home_page/content', 'categories-section');
        endif;

        $recent_posts = wp_get_recent_posts(array(
            'numberposts' => 1, // Number of recent posts thumbnails to display
            'post_status' => 'publish' // Show only the published posts
        ));
        if (sizeof($recent_posts) > 0) :
            get_template_part('template-parts/home_page/content', 'recent-posts-section');
        endif;
        ?>
    </div>
</main>

<?php get_footer(); ?>