<?php
if (!function_exists('pyme_comments')) :
    function pyme_comments($comment, $args, $depth)
    {
?>

        <div class="card-body rounded shadow">
            <div class="d-flex flex-start align-items-center">
                <img class="rounded-circle shadow-1-strong me-3" src="<?php echo esc_url(get_avatar_url($comment, $size = '80', $default = esc_url(get_template_directory_uri()) . '/assets/images/avatar.png')); ?>" alt="<?php esc_attr_e('avatar', 'pyme') ?>" width="60" height="60" />
                <div>
                    <h6 class="fw-bold text-primary mb-1 primary-color"><?php echo esc_html(get_comment_author()) ?></h6>
                    <p class="text-muted small mb-0">
                        <?php printf(esc_html('%1$s - %2$s'), esc_html(get_comment_date()),  esc_html(get_comment_time())) ?>
                    </p>
                    <?php if ($comment->comment_approved == '0') : ?>
                        <em><?php esc_html_e('Su comentario está a la espera de ser aprobado', 'pyme') ?>.</em>
                        <br />
                    <?php endif; ?>
                </div>
            </div>

            <p class="mt-3 mb-4 pb-2">
                <?php echo get_comment_text() ?>
            </p>

            <div class="small d-flex justify-content-start">
                <a href="#!" class="d-flex align-items-center me-2">
                    <svg width="15" height="15" version="1.1" id="Capa_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 58 58" style="enable-background:new 0 0 58 58;" xml:space="preserve">
                        <g>
                            <path style="fill:#546A79;" d="M29,1.5c-16.016,0-29,11.641-29,26c0,5.292,1.768,10.211,4.796,14.318
		C4.398,46.563,3.254,53.246,0,56.5c0,0,9.943-1.395,16.677-5.462c0.007,0.003,0.015,0.006,0.022,0.009
		c2.764-1.801,5.532-3.656,6.105-4.126c0.3-0.421,0.879-0.548,1.33-0.277c0.296,0.178,0.483,0.503,0.489,0.848
		c0.01,0.622-0.005,0.784-5.585,4.421C22.146,52.933,25.498,53.5,29,53.5c16.016,0,29-11.641,29-26S45.016,1.5,29,1.5z" />
                            <circle style="fill:#FFFFFF;" cx="15" cy="27.5" r="3" />
                            <circle style="fill:#FFFFFF;" cx="29" cy="27.5" r="3" />
                            <circle style="fill:#FFFFFF;" cx="43" cy="27.5" r="3" />
                        </g>
                    </svg>
                    <p class="mb-0"><?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></p>
                </a>
            </div>
        </div>

<?php
    }
endif;
