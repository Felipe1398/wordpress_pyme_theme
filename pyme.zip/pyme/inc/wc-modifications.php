<?php

function pyme_wc_modify()
{

    function pyme_remove_shop_title($val)
    {
        $val = false;
        return $val;
    }
    add_filter('woocommerce_show_page_title', 'pyme_remove_shop_title');


    function pyme_add_title_container()
    {
        echo '<div class="title-container text-center primary-color">';
    }
    add_action('woocommerce_breadcrumb', 'pyme_add_title_container', 1);


    function pyme_add_title_tags()
    {
        echo '<h1>';
    }
    add_action('woocommerce_breadcrumb', 'pyme_add_title_tags', 2);


    function pyme_add_shop_title()
    {
        echo woocommerce_page_title();
    }
    add_action('woocommerce_breadcrumb', 'pyme_add_shop_title', 3);


    function pyme_close_title_tags()
    {
        echo '</h1>';
    }
    add_action('woocommerce_breadcrumb', 'pyme_close_title_tags', 4);


    function pyme_close_title_container()
    {
        echo '</div>';
    }
    if (is_product()) {
        add_action('woocommerce_before_single_product', 'pyme_close_title_container', 1);
    } else {
        add_action('woocommerce_archive_description', 'pyme_close_title_container', 1);
    }


    function pyme_open_container()
    {
        echo '<div class="container"><div class="row">';
    }
    if (is_product()) {
        add_action('woocommerce_before_single_product', 'pyme_open_container', 11);
    } else {
        add_action('woocommerce_before_shop_loop', 'pyme_open_container', 11);
    }


    remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar');
    if (is_product()) {
        add_action('woocommerce_before_shop_loop', 'woocommerce_get_sidebar', 12);
    } else {
        add_action('woocommerce_before_shop_loop', 'woocommerce_get_sidebar', 12);
    }


    function pyme_add_shop_tags()
    {
        echo '<div class="col">';
    }
    if (is_product()) {
        add_action('woocommerce_before_single_product', 'pyme_add_shop_tags', 13);
    } else {
        add_action('woocommerce_before_shop_loop', 'pyme_add_shop_tags', 13);
    }


    function pyme_close_shop_tags()
    {
        echo '</div>';
    }
    add_action('woocommerce_after_main_content', 'pyme_close_shop_tags', 5);


    function pyme_close_container()
    {
        echo '</div></div>';
    }
    add_action('woocommerce_after_main_content', 'pyme_close_container', 6);


    function pyme_add_product_tags()
    {
        echo '<div class="text-center product-info">';
    }
    add_action('woocommerce_shop_loop_item_title', 'pyme_add_product_tags', 1);


    function pyme_close_product_tags()
    {
        echo '</div>';
    }
    add_action(' woocommerce_after_shop_loop_item', 'pyme_close_product_tags');


    function pyme_open_account_nav_sidebar()
    {
        echo '<div class="offcanvas offcanvas-start secondary-color-bg" tabindex="-1" id="offcanvasAccountNav" aria-labelledby="offcanvasAccountNavLabel">
                <div class="offcanvas-header">
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">';
    }
    add_action('woocommerce_before_account_navigation', 'pyme_open_account_nav_sidebar', 1);


    function pyme_close_account_nav_sidebar()
    {
        echo '</div>
            </div>
            <a data-bs-toggle="offcanvas" href="#offcanvasAccountNav" role="button" aria-controls="offcanvasAccountNav">
                <svg class="mb-4" xmlns="https://www.w3.org/2000/svg" viewBox="0 0 24 24" width="35" height="35">
                    <path d="M2 5L2 7L22 7L22 5L2 5 z M 2 11L2 13L22 13L22 11L2 11 z M 2 17L2 19L22 19L22 17L2 17 z" fill="#000000" />
                </svg>
            </a>';
    }
    add_action('woocommerce_after_account_navigation', 'pyme_close_account_nav_sidebar', 1);


    function pyme_add_bootstrap_input_classes($args, $key, $value = null)
    {

        // Start field type switch case
        switch ($args['type']) {

            case "select":  /* Targets all select input type elements, except the country and state select input types */
                $args['class'][] = 'form-group'; // Add a class to the field's html element wrapper - woocommerce input types (fields) are often wrapped within a <p></p> tag
                $args['input_class'] = array('form-control', 'input-lg'); // Add a class to the form input itself
                //$args['custom_attributes']['data-plugin'] = 'select2';
                $args['label_class'] = array('control-label');
                $args['custom_attributes'] = array('data-plugin' => 'select2', 'data-allow-clear' => 'true', 'aria-hidden' => 'true',); // Add custom data attributes to the form input itself
                break;

            case 'country': /* By default WooCommerce will populate a select with the country names - $args defined for this specific input type targets only the country select element */
                $args['class'][] = 'form-group single-country';
                $args['label_class'] = array('control-label');
                break;

            case "state": /* By default WooCommerce will populate a select with state names - $args defined for this specific input type targets only the country select element */
                $args['class'][] = 'form-group'; // Add class to the field's html element wrapper
                $args['input_class'] = array('form-control', 'input-lg'); // add class to the form input itself
                //$args['custom_attributes']['data-plugin'] = 'select2';
                $args['label_class'] = array('control-label');
                $args['custom_attributes'] = array('data-plugin' => 'select2', 'data-allow-clear' => 'true', 'aria-hidden' => 'true',);
                break;

            case "password":
            case "text":
            case "email":
            case "tel":
            case "number":
                $args['class'][] = 'form-group';
                //$args['input_class'][] = 'form-control input-lg'; // will return an array of classes, the same as bellow
                $args['input_class'] = array('form-control', 'input-lg');
                $args['label_class'] = array('control-label');
                break;

            case 'textarea':
                $args['input_class'] = array('form-control', 'input-lg');
                $args['label_class'] = array('control-label');
                break;

            case 'checkbox':
                break;

            case 'radio':
                break;

            default:
                $args['class'][] = 'form-group';
                $args['input_class'] = array('form-control', 'input-lg');
                $args['label_class'] = array('control-label');
                break;
        }

        return $args;
    }
    add_filter('woocommerce_form_field_args', 'pyme_add_bootstrap_input_classes', 10, 3);


    function pyme_remove_comment_reply_link($link)
    {
        return '';
    }
    add_filter('cancel_comment_reply_link', 'pyme_remove_comment_reply_link');


    function pyme_create_cancel_button($post_id)
    {
        remove_filter('cancel_comment_reply_link', 'pyme_remove_comment_reply_link');
        cancel_comment_reply_link(esc_html__('Cancelar respuesta', 'pyme'));
    }
    add_action('comment_form', 'pyme_create_cancel_button');
}
add_action('wp', 'pyme_wc_modify');
