<?php

/**
 * PYME Theme Customizer
 *
 * @package Pyme
 */

function pyme_customizer($wp_customize)
{

    /*******************************************
    General customizations
     ********************************************/
    require get_template_directory() . '/inc/customizations/general_customization.php';
    /*******************************************

    /*******************************************
    Color scheme customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/color_scheme_customization.php';
    /*******************************************

    /*******************************************
    Carousel customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/carousel_customization.php';
    /*******************************************/

    /*******************************************
    Features customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/features_customization.php';
    /*******************************************/

    /*******************************************
    About company section customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/about_customization.php';
    /*******************************************/

    /*******************************************
    Recent posts customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/recent_posts_customization.php';
    /*******************************************/

    /*******************************************
    About page customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/about_page_customization.php';
    /*******************************************/

    /*******************************************
    Contact page customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/contact_page_customization.php';
    /*******************************************/

    /*******************************************
    Footer customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/footer_customization.php';
    /*******************************************/

    /*******************************************
    Posts customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/post_customization.php';
    /*******************************************/

    /*******************************************
    Login page customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/login_page_customization.php';
    /*******************************************/

    /*******************************************
    Account page customization
     ********************************************/
    require get_template_directory() . '/inc/customizations/account_page_customization.php';
    /*******************************************/

    // Woocommerce
    if (class_exists('WooCommerce')) {

        /*******************************************
        Popular products customization
         ********************************************/
        require get_template_directory() . '/inc/customizations/pupular_products_customization.php';
        /*******************************************/

        /*******************************************
        Product categories customization
         ********************************************/
        require get_template_directory() . '/inc/customizations/categories_customization.php';
        /*******************************************/

        /*******************************************
        Products customization
         ********************************************/
        require get_template_directory() . '/inc/customizations/product_customization.php';
        /*******************************************/
    }
}
add_action('customize_register', 'pyme_customizer');


/*******************************************
Sanitization Callbacks
 *********************************************/
require get_template_directory() . '/inc/sanitization-callbacks.php';
/*******************************************/




function pyme_customize_styles()
{
    $title_border_enable = get_theme_mod('set_border_enable', false);
    $title_border_shadow_enable = get_theme_mod('set_border_shadow_enable', false);

    // primary color
    $primary_color = get_theme_mod('set_primary_color', '#008037');
    // secondary color
    $secondary_color = get_theme_mod('set_secondary_color', '#dbd0c4');

    $icons_color = get_theme_mod('set_icons_color', '#FFFFFF');

    $carousel_controls_color = get_theme_mod('set_carousel_controls_color', $primary_color);

    $feature_texts_color = get_theme_mod('set_feature_texts_color', $primary_color);

    $popular_products_title_color = get_theme_mod('set_popular_products_title_color', $primary_color);
    $popular_products_subtitle_color = get_theme_mod('set_popular_products_subtitle_color', $primary_color);

    $about_title_color = get_theme_mod('set_about_title_color', $primary_color);
    $about_subtitle_color = get_theme_mod('set_about_subtitle_color', $primary_color);
    $about_description_color = get_theme_mod('set_about_description_color', $primary_color);
    $about_carousel_controls_color = get_theme_mod('set_about_carousel_controls_color', $primary_color);

    $categories_title_color = get_theme_mod('set_categories_title_color', $primary_color);
    $categories_subtitle_color = get_theme_mod('set_categories_subtitle_color', $primary_color);
    $categories_name_color = get_theme_mod('set_categories_name_color', $primary_color);
    $categories_background_color = get_theme_mod('set_categories_background_color', '#ffffff');

    $recent_posts_title_color = get_theme_mod('set_recent_posts_title_color', $primary_color);
    $recent_posts_subtitle_color = get_theme_mod('set_recent_posts_subtitle_color', $primary_color);

    $about_company_title_color = get_theme_mod('set_about_company_title_color', $primary_color);
    $about_company_subtitle_color = get_theme_mod('set_about_company_subtitle_color', $primary_color);
    $about_company_txt_color = get_theme_mod('set_about_company_txt_color', '#000000');
    $about_company_bk_color = get_theme_mod('set_about_company_bk_color', '#ffffff');

    $about_team_section_title_color = get_theme_mod('set_about_team_section_title_color', $primary_color);
    $about_team_section_subtitle_color = get_theme_mod('set_about_team_section_subtitle_color', $primary_color);
    $about_team_section_bk_color = get_theme_mod('set_about_team_section_bk_color', '#ffffff');
    $about_team_section_txt_color = get_theme_mod('set_about_team_section_txt_color', $primary_color);
    $about_team_section_btn_color = get_theme_mod('set_about_team_section_btn_color', $primary_color);
    $about_team_section_btn_txt_color = get_theme_mod('set_about_team_section_btn_txt_color', '#ffffff');
    $about_team_section_border_color = get_theme_mod('set_about_team_section_border_color', '#ffffff');

    $about_products_title_color = get_theme_mod('set_about_products_title_color', $primary_color);
    $about_products_subtitle_color = get_theme_mod('set_about_products_subtitle_color', $primary_color);
    $about_products_card_bk_color = get_theme_mod('set_about_products_card_bk_color', '#ffffff');
    $about_products_card_txt_color = get_theme_mod('set_about_products_card_txt_color', '#000000');
    $about_products_card_feature_color = get_theme_mod('set_about_products_card_feature_color', $primary_color);

    $social_networks_title_color = get_theme_mod('set_social_networks_title_color', $primary_color);
    $social_networks_subtitle_color = get_theme_mod('set_social_networks_subtitle_color', $primary_color);
    $social_network_icons_color = get_theme_mod('set_social_network_icons_color', '#ffffff');
    $social_networks_bk_color = get_theme_mod('set_social_networks_bk_color', $primary_color);

    $contact_info_title_color = get_theme_mod('set_contact_info_title_color', $primary_color);
    $contact_info_subtitle_color = get_theme_mod('set_contact_info_subtitle_color', $primary_color);
    $contact_info_bk_color = get_theme_mod('set_contact_info_bk_color', '#ffffff');

    $product_color = get_theme_mod('set_product_color', $primary_color);
    $product_background = get_theme_mod('set_product_background', '#f2f2f2');
    $product_btn_background = get_theme_mod('set_product_btn_background', $primary_color);
    $product_btn_color = get_theme_mod('set_product_btn_color', '#ffffff');
    $onsale_tag_background = get_theme_mod('set_onsale_tag_background', $primary_color);
    $onsale_tag_color = get_theme_mod('set_onsale_tag_color', '#ffffff');
    $product_border = get_theme_mod('set_product_border', '#ffffff');

    $post_title_color = get_theme_mod('set_post_title_color', $primary_color);
    $post_txt_color = get_theme_mod('set_post_txt_color', '#000000');
    $post_background = get_theme_mod('set_post_background', '#f2f2f2');
    $post_btn_background = get_theme_mod('set_post_btn_background', $primary_color);
    $post_btn_color = get_theme_mod('set_post_btn_color', '#ffffff');
    $date_tag_background = get_theme_mod('set_date_tag_background', $primary_color);
    $date_tag_color = get_theme_mod('set_date_tag_color', '#ffffff');
    $post_border = get_theme_mod('set_post_border', '#ffffff');

    $links_color = get_theme_mod('set_links_color', $primary_color);
    $links_hover_color = get_theme_mod('set_links_hover_color', $primary_color);
    $nav_links_color = get_theme_mod('set_nav_links_color', $primary_color);
    $nav_links_hover_color = get_theme_mod('set_nav_links_hover_color', $primary_color);
    $footer_links_color = get_theme_mod('set_footer_links_color', $primary_color);
    $footer_links_hover_color = get_theme_mod('set_footer_links_hover_color', $primary_color);

    $account_primary_color = get_theme_mod('set_account_primary_color', '#000000');
    $login_primary_color = get_theme_mod('set_login_primary_color', '#000000');



    /****************************************
    Varible Styles
     ****************************************/
?>
    <style>
        /* ########## GLOBAL STYLES ########## */

        .primary-color {
            color: <?php echo $primary_color; ?> !important;
        }

        .secondary-color {
            color: <?php echo $secondary_color; ?> !important;
        }

        .primary-color-bg {
            background-color: <?php echo $primary_color; ?> !important;
        }

        .secondary-color-bg {
            background-color: <?php echo $secondary_color; ?> !important;
        }

        textarea:focus,
        input[type="text"]:focus,
        input[type="password"]:focus,
        input[type="datetime"]:focus,
        input[type="datetime-local"]:focus,
        input[type="date"]:focus,
        input[type="month"]:focus,
        input[type="time"]:focus,
        input[type="week"]:focus,
        input[type="number"]:focus,
        input[type="email"]:focus,
        input[type="url"]:focus,
        input[type="search"]:focus,
        input[type="tel"]:focus,
        input[type="color"]:focus,
        .uneditable-input:focus {
            border-color: <?php echo $primary_color; ?> !important;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px <?php echo $primary_color; ?> !important;
        }

        a {
            color: <?php echo $links_color; ?>;
        }

        a:not(.button, .btn, .woocommerce-store-notice__dismiss-link, .dropdown-item):hover {
            color: <?php echo $links_hover_color; ?>;
        }

        .btn:focus,
        .btn-close:focus {
            border: 1px solid <?php echo $primary_color;
                                ?>;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px <?php echo $primary_color; ?> !important;
        }

        .btn:hover,
        .btn-close:hover {
            border: 1px solid <?php echo $primary_color; ?>;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px <?php echo $primary_color; ?> !important;
        }

        .svg-icon-color {
            fill: <?php echo $icons_color; ?>;
        }

        .svg-icon-primary-color {
            fill: <?php echo $primary_color; ?>;
        }

        .carousel-control-prev-icon {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M13 3L7 12L13 21L17 21L11 12L17 3L13 3 z' fill='%23<?php echo str_replace("#", "", $carousel_controls_color); ?>' /%3E%3C/svg%3E");
        }

        .carousel-control-next-icon {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M8 3L14 12L8 21L12 21L18 12L12 3L8 3 z' fill='%23<?php echo str_replace("#", "", $carousel_controls_color); ?>' /%3E%3C/svg%3E");
        }

        .site-title {
            color: <?php echo $primary_color; ?>;
        }

        /* ########## END GLOBAL STYLES ########## */



        /* ########## HEADER STYLES ########## */

        .title-container::after {
            background-color: <?php echo $secondary_color; ?>;
        }

        <?php if ($title_border_enable) { ?>.title-container::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 50%;
            z-index: -1;
            border-radius: 0 0 50% 50%/0 0 100% 100%;
            transform: scaleX(2);
        }

        @media (min-width: 992px) {
            .title-container::after {
                height: 95%;
                transform: scaleX(1.5);
            }
        }

        <?php } else { ?>.title-container {
            background-color: <?php echo $secondary_color; ?>;
        }

        <?php } ?><?php if ($title_border_shadow_enable) {
                        if ($title_border_enable) { ?>.title-container::after {
            -webkit-box-shadow: 0px 10px 5px 0px rgba(50, 50, 50, 0.75);
            -moz-box-shadow: 0px 10px 5px 0px rgba(50, 50, 50, 0.75);
            box-shadow: 0px 10px 5px 0px rgba(50, 50, 50, 0.75);
        }

        <?php } else { ?>.title-container {
            -webkit-box-shadow: 0px 10px 5px 0px rgba(50, 50, 50, 0.75);
            -moz-box-shadow: 0px 10px 5px 0px rgba(50, 50, 50, 0.75);
            box-shadow: 0px 10px 5px 0px rgba(50, 50, 50, 0.75);
        }

        <?php }
                    } ?>header .dropdown-toggle {
            color: <?php echo $icons_color; ?> !important;
        }

        header .dropdown-toggle:hover {
            color: <?php echo $icons_color; ?> !important;
        }

        header .cart-items {
            color: <?php echo $secondary_color; ?> !important;
        }

        .main-menu-container ul li a {
            color: <?php echo $nav_links_color; ?> !important;
        }

        .main-menu-container ul li a:hover {
            color: <?php echo $nav_links_hover_color; ?> !important;
        }

        /* ########## END HEADER STYLES ########## */



        /* ########## HOME PAGE STYLES ########## */

        /* main carousel styles */

        <?php $num_slides = get_theme_mod('set_num_slides', 0);

        for ($i = 1; $i <= $num_slides; $i++) {

            $slide_title_color = get_theme_mod('carousel_title_color' . $i, '#000000');

            $slide_subtitle_color = get_theme_mod('carousel_subtitle_color' . $i, '#000000');

            $slide_btn_color = get_theme_mod('carousel_btn_color' . $i, '#008037');

            $slide_btn_txt_color = get_theme_mod('carousel_btn_txt_color' . $i, '#ffffff');

            $slide_title_color_style = '#main-carousel-section .carousel-title-' . $i . ' h1 {color: ' . $slide_title_color . ';}';

            $slide_subtitle_color_style = '#main-carousel-section .carousel-description .carousel-subtitle-' . $i . ' p {color: ' . $slide_subtitle_color . ' !important;}';

            $slide_btn_color_style = '#main-carousel-section .carousel-description .carousel-btn-' . $i . ' .btn {background-color: ' . $slide_btn_color . ' !important;color: ' . $slide_btn_txt_color . ' !important;}';

            echo $slide_title_color_style;
            echo $slide_subtitle_color_style;
            echo $slide_btn_color_style;
        }

        ?>
        /* end main carousel styles */


        /* features section styles */

        #features-section .card {
            border: 3px solid <?php echo $primary_color; ?> !important;
        }

        #features-section .card .card-body .card-title {
            color: <?php echo $feature_texts_color; ?> !important;
        }

        /* end features section styles */


        /* popular products section styles */

        #popular-products-section .card .card-body .card-title {
            color: <?php echo $popular_products_title_color; ?>;
        }

        #popular-products-section .card .card-body .card-description {
            color: <?php echo $popular_products_subtitle_color; ?>;
        }



        /* end popular products section styles */


        /* about company section styles */

        #about-section .card .card-body .card-title {
            color: <?php echo $about_title_color;
                    ?>;
        }

        #about-section .card .card-body .card-description {
            color: <?php echo $about_subtitle_color;
                    ?>;
        }

        #about-section .card .card-body .description {
            color: <?php echo $about_description_color;
                    ?>;
        }

        #about-section .carousel-control-prev-icon {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M13 3L7 12L13 21L17 21L11 12L17 3L13 3 z' fill='%23<?php echo str_replace("#", "", $about_carousel_controls_color); ?>' /%3E%3C/svg%3E");
        }

        #about-section .carousel-control-next-icon {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M8 3L14 12L8 21L12 21L18 12L12 3L8 3 z' fill='%23<?php echo str_replace("#", "", $about_carousel_controls_color); ?>' /%3E%3C/svg%3E");
        }

        /* end about company section styles */


        /* categories section styles */

        #categories-section .card .card-body .card-title {
            color: <?php echo $categories_title_color; ?>;
        }

        #categories-section .card .card-body .card-description {
            color: <?php echo $categories_subtitle_color; ?>;
        }

        #categories-section .row .col .card .card-body .card-title {
            color: <?php echo $categories_name_color; ?>;
        }

        #categories-section .row .col .card {
            background-color: <?php echo $categories_background_color; ?>;
        }

        #categories-section .row .col .card {
            border: 4px solid <?php echo $primary_color; ?>;
        }

        /* end categories section styles */


        /* recent posts section styles */

        #recent-posts-section .card .card-body .card-title {
            color: <?php echo $recent_posts_title_color; ?>;
        }

        #recent-posts-section .card .card-body .card-description {
            color: <?php echo $recent_posts_subtitle_color; ?>;
        }

        /* end recent posts section styles */

        /* ########## END HOME PAGE STYLES ########## */



        /* ########## BLOG PAGE STYLES ########## */

        .comments-section #reply-title>a {
            color: <?php echo $primary_color; ?>;
        }

        .post-page-numbers.current {
            color: <?php echo $primary_color; ?>;
        }

        .post-page-numbers:hover {
            color: <?php echo $primary_color; ?>;
        }

        .pagination .page-item.active .page-link {
            background-color: <?php echo $primary_color; ?>;
            border-color: <?php echo $primary_color; ?>;
        }

        .pagination .page-item .page-link {
            color: <?php echo $primary_color; ?>;
        }

        .pagination .prev.page-link:focus,
        .pagination .next.page-link:focus {
            border-color: <?php echo $primary_color; ?> !important;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px <?php echo $primary_color; ?> !important;
        }

        .nothing {
            color: <?php echo $primary_color; ?>;
        }

        .post-card {
            background-color: <?php echo $post_background; ?> !important;
            border: 0.10rem solid <?php echo $post_border; ?>;
        }

        .post-card .card-title {
            color: <?php echo $post_title_color; ?> !important;
        }

        .post-card .meta,
        .post-card .excerpt p {
            color: <?php echo $post_txt_color; ?>;
        }

        .post-card a.btn {
            background-color: <?php echo $post_btn_background; ?> !important;
            color: <?php echo $post_btn_color; ?> !important;
        }

        .post-card .badge {
            background-color: <?php echo $date_tag_background; ?>;
            color: <?php echo $date_tag_color; ?> !important;
        }

        /* ########## END BLOG PAGE STYLES ########## */



        /* ########## ABOUT PAGE STYLES ########## */

        .about-page .carousel-control-prev-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23<?php echo str_replace("#", "", $about_carousel_controls_color); ?>'%3e%3cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z'/%3e%3c/svg%3e");
            font-size: 200%;
        }

        .about-page .carousel-control-next-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23<?php echo str_replace("#", "", $about_carousel_controls_color); ?>'%3e%3cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
            font-size: 200%;
        }

        #about-company-section .card .card-body .card-title {
            color: <?php echo $about_company_title_color; ?>;
        }

        #about-company-section .card .card-body .card-description {
            color: <?php echo $about_company_subtitle_color; ?>;
        }

        #about-company-section .card .card {
            color: <?php echo $about_company_txt_color; ?>;
            background-color: <?php echo $about_company_bk_color; ?>;
        }

        #about-team-section .card .card-body .card-title {
            color: <?php echo $about_team_section_title_color; ?>;
        }

        #about-team-section .card .card-body .card-description {
            color: <?php echo $about_team_section_subtitle_color; ?>;
        }

        #about-team-section .member-card {
            background-color: <?php echo $about_team_section_bk_color; ?>;
            border: 0.10rem solid <?php echo $about_team_section_border_color; ?>;
        }

        #about-team-section .member-card .card-title {
            color: <?php echo $about_team_section_txt_color; ?> !important;
        }

        #about-team-section .member-card button {
            color: <?php echo $about_team_section_btn_txt_color; ?> !important;
            background-color: <?php echo $about_team_section_btn_color; ?> !important;
        }

        #about-products-section .card .card-body .card-title {
            color: <?php echo $about_products_title_color; ?>;
        }

        #about-products-section .card .card-body .card-description {
            color: <?php echo $about_products_subtitle_color; ?>;
        }

        #about-products-section .card .card .card-title {
            color: <?php echo $about_products_card_feature_color; ?> !important;
        }

        #about-products-section .card .card .card-text {
            color: <?php echo $about_products_card_txt_color; ?>;
        }

        #about-products-section .card .card {
            background-color: <?php echo $about_products_card_bk_color; ?>;
        }

        /* ########## END ABOUT PAGE STYLES ########## */



        /* ########## CONTACT PAGE STYLES ########## */

        #contact-info-section .card .card-body .card-title {
            color: <?php echo $contact_info_title_color; ?>;
        }

        #contact-info-section .card .card-body .card-description {
            color: <?php echo $contact_info_subtitle_color; ?>;
        }

        #contact-info-section .card .card {
            background-color: <?php echo $contact_info_bk_color; ?>;
        }

        #social-networks-section .card .card-body .card-title {
            color: <?php echo $social_networks_title_color; ?>;
        }

        #social-networks-section .card .card-body .card-description {
            color: <?php echo $social_networks_subtitle_color; ?>;
        }

        #social-networks-section .card .social-media-card {
            background-color: <?php echo $social_networks_bk_color; ?>;
        }

        #social-networks-section .card .social-media-card .svg-icon-network {
            fill: <?php echo $social_network_icons_color; ?>;
        }

        /* ########## END CONTACT PAGE STYLES ########## */



        /* ########## SHOP STYLES ########## */

        .woocommerce ul li.product {
            border: 3px solid <?php echo $primary_color; ?>;
        }

        .summary .product_title {
            color: <?php echo $primary_color; ?>;
        }

        .product-info .woocommerce-loop-product__title,
        .woocommerce ul.products li.product .price,
        .woocommerce-Price-amount,
        .product_title,
        .woocommerce-Tabs-panel h2,
        .related.products h2,
        .up-sells h2,
        .cart_totals h2,
        .shop_table th,
        .woocommerce-message,
        .woocommerce-message::before,
        .woocommerce-message::after,
        .woocommerce .star-rating span::before {
            color: <?php echo $product_color; ?> !important;
        }

        .woocommerce-message {
            color: <?php echo $product_color; ?> !important;
            border-color: <?php echo $product_color; ?> !important;
        }

        .button,
        #commentform #submit {
            background-color: <?php echo $product_btn_background; ?> !important;
        }

        .button,
        #commentform #submit {
            color: <?php echo $product_btn_color; ?> !important;
        }

        .woocommerce ul.products li.product {
            background-color: <?php echo $product_background; ?>;
            border: 0.15rem solid <?php echo $product_border; ?>;
        }

        .onsale {
            background-color: <?php echo $onsale_tag_background; ?> !important;
            color: <?php echo $onsale_tag_color; ?> !important;
        }



        /* ########## END SHOP STYLES ########## */



        /* ########## ACCOUNT PAGE STYLES ########## */

        .woocommerce-Address,
        .woocommerce-MyAccount-content {
            border: 2px solid <?php echo $account_primary_color; ?> !important;
        }

        .woocommerce-Address,
        .woocommerce-MyAccount-content a:not(.button) {
            color: <?php echo $account_primary_color; ?> !important;
        }

        /* ########## END ACCOUNT PAGE STYLES ########## */



        /* ########## LOGIN PAGE STYLES ########## */

        #customer_login h2 {
            color: <?php echo $login_primary_color; ?>;
        }

        .woocommerce-form-login,
        .woocommerce-form-register {
            border: 2px solid <?php echo $login_primary_color; ?> !important;
        }

        /* ########## END LOGIN PAGE STYLES ########## */



        /* ########## WOOCOMMERCE NOTICE STYLES ########## */

        p.woocommerce-store-notice.demo_store {
            background-color: <?php echo $primary_color; ?> !important;
            color: <?php echo $secondary_color; ?> !important;
        }

        a.woocommerce-store-notice__dismiss-link {
            color: <?php echo $secondary_color; ?> !important;
        }

        /* ########## END WOOCOMMERCE NOTICE STYLES ########## */



        /* ########## WOOCOMMERCE BREADCRUMB STYLES ########## */

        .woocommerce .woocommerce-breadcrumb {
            color: <?php echo $primary_color; ?>;
        }

        .woocommerce .woocommerce-breadcrumb a {
            color: <?php echo $primary_color; ?>;
        }

        /* ########## WOOCOMMERCE BREADCRUMB STYLES ########## */



        /* ########## FOOTER STYLES ########## */

        footer a {
            color: <?php echo $footer_links_color; ?> !important;
        }

        footer a:hover {
            color: <?php echo $footer_links_hover_color; ?> !important;
        }

        /* ########## FOOTER STYLES ########## */
    </style>
<?php
}
add_action('wp_head', 'pyme_customize_styles');
