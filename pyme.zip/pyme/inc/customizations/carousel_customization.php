<?php

// Carousel panel

$wp_customize->add_panel('carousel_panel', array(
    'title' => __('Carrusel', 'pyme'),
    'description' => __('Configuraciones del carrusel', 'pyme'),
    'priority' => 1002
));

// Carousel general configs

$wp_customize->add_section(
    'sec_carousel_general_configs',
    array(
        'title' => __('Configuración general', 'pyme'),
        'description' => __('Ajustes generales del carrusel', 'pyme'),
        'panel' => 'carousel_panel'
    )
);

// Number of slides to desplay

$wp_customize->add_setting(
    'set_num_slides',
    array(
        'type' => 'theme_mod',
        'default' => 0,
        'sanitize_callback' => 'absint'
    )
);

$wp_customize->add_control(
    'set_num_slides',
    array(
        'label' => __('Número de slides', 'pyme'),
        'description' => __('Ingrese el número de slides a mostrar. IMPORTANTE: DEBE APLICAR LOS CAMBIOS Y REFRESCAR ESTA PÁGINA PARA QUE ESTE CAMBIO SURTA EFECTO.', 'pyme'),
        'section' => 'sec_carousel_general_configs',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 0,
            'max' => 10
        )
    )
);

// Carousel controls color

$wp_customize->add_setting(
    'set_carousel_controls_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_carousel_controls_color',
        array(
            'label' => __('Color de los controles del carrusel', 'pyme'),
            'description' => __('Seleccione el color de los controles del carrusel', 'pyme'),
            'section' => 'sec_carousel_general_configs',
            'priority' => 8
        )
    )
);

// Add settings for each of the slides

$num_slides = get_theme_mod('set_num_slides', 0);
for ($i = 1; $i <= $num_slides; $i++) {

    $sec_carousel_control_priority = 1;

    //Add section for each slide

    $wp_customize->add_section(
        'sec_carousel' . $i,
        array(
            'title' => __('Configuración del slide', 'pyme') . ' ' . $i,
            'description' => __('Configure la información que se muestra en el slide', 'pyme') . ' ' . $i,
            'panel' => 'carousel_panel'
        )
    );

    // Slide page

    $wp_customize->add_setting(
        'set_carousel_page' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'absint'
        )
    );

    $wp_customize->add_control(
        'set_carousel_page' . $i,
        array(
            'label' => __('Página del slide', 'pyme'),
            'description' => __('Agregue la página del slide (cree una página con un título, imagen destacada y texto como subtítulo)', 'pyme'),
            'section' => 'sec_carousel' . $i,
            'type' => 'dropdown-pages',
            'priority' => $sec_carousel_control_priority
        )
    );

    $sec_carousel_control_priority++;

    // Slide button text

    $wp_customize->add_setting(
        'set_carousel_button_text' . $i,
        array(
            'type' => 'theme_mod',
            'default' => __('Comprar ahora', 'pyme'),
            'sanitize_callback' => 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_carousel_button_text' . $i,
        array(
            'label' => __('Texto del botón', 'pyme'),
            'description' => __('Agregue un texto al botón', 'pyme'),
            'section' => 'sec_carousel' . $i,
            'type' => 'text',
            'priority' => $sec_carousel_control_priority
        )
    );

    $sec_carousel_control_priority++;

    // Slide button visibility

    $wp_customize->add_setting(
        'set_carousel_button_visibility' . $i,
        array(
            'type' => 'theme_mod',
            'default' => true,
            'sanitize_callback' => 'pyme_sanitize_checkbox'
        )
    );

    $wp_customize->add_control(
        'set_carousel_button_visibility' . $i,
        array(
            'label' => __('Mostrar botón', 'pyme'),
            'description' => __('Muestre u oculte el botón', 'pyme'),
            'section' => 'sec_carousel' . $i,
            'type'  => 'checkbox',
            'priority' => $sec_carousel_control_priority
        )
    );

    $sec_carousel_control_priority++;

    // Slide button URL

    $wp_customize->add_setting(
        'set_carousel_button_url' . $i,
        array(
            'type' => 'theme_mod',
            'default' => 'https://www.google.com/',
            'sanitize_callback' => 'esc_url_raw'
        )
    );

    $wp_customize->add_control(
        'set_carousel_button_url' . $i,
        array(
            'label' => __('URL del botón', 'pyme'),
            'description' => __('Agregue la URL del botón', 'pyme'),
            'section' => 'sec_carousel' . $i,
            'type' => 'url',
            'priority' => $sec_carousel_control_priority
        )
    );

    $sec_carousel_control_priority++;

    // Slide image and text position

    $wp_customize->add_setting(
        'set_carousel_position' . $i,
        array(
            'type' => 'theme_mod',
            'default' => 0,
            'sanitize_callback' => 'pyme_sanitize_select'
        )
    );

    $wp_customize->add_control(
        'set_carousel_position' . $i,
        array(
            'label' => __('Posición de la imagen y texto', 'pyme'),
            'description' => __('Seleccione la posición de la imagen y el texto', 'pyme'),
            'section' => 'sec_carousel' . $i,
            'type' => 'select',
            'choices' => array(
                '0' => __('Imagen a la izquierda', 'pyme') . ' - ' . __('texto a la derecha', 'pyme'),
                '1' => __('Imagen a la derecha', 'pyme') . ' - ' . __('texto a la izquierda', 'pyme'),
                '2' => __('Imagen de fondo', 'pyme') . ' - ' . __('texto sobre la imagen', 'pyme')
            ),
            'priority' => $sec_carousel_control_priority
        )
    );

    $sec_carousel_control_priority++;

    // Slide title color

    $carousel_colors[] = array(
        'slug' => 'carousel_title_color' . $i,
        'default' => '#000000',
        'label' => __('Color del título', 'pyme'),
        'description' => __('Seleccione el color del título', 'pyme'),
    );

    // Slide subtitle color

    $carousel_colors[] = array(
        'slug' => 'carousel_subtitle_color' . $i,
        'default' => '#000000',
        'label' => __('Color del subtítulo', 'pyme'),
        'description' => __('Seleccione el color del subtítulo', 'pyme'),
    );

    // Slide button color

    $carousel_colors[] = array(
        'slug' => 'carousel_btn_color' . $i,
        'default' => '#008037',
        'label' => __('Color de los botones', 'pyme'),
        'description' => __('Seleccione el color de fondo del boton', 'pyme'),
    );

    // Slide button text color

    $carousel_colors[] = array(
        'slug' => 'carousel_btn_txt_color' . $i,
        'default' => '#ffffff',
        'label' => __('Seleccione el color del texto del botón', 'pyme'),
        'description' => __('Color del texto del boton', 'pyme'),
    );

    foreach ($carousel_colors as $carousel_color) {

        $wp_customize->add_setting(
            $carousel_color['slug'],
            array(
                'type' => 'theme_mod',
                'default' => $carousel_color['default'],
                'sanitize_callback' => 'sanitize_hex_color'
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                $carousel_color['slug'],
                array(
                    'label' => $carousel_color['label'],
                    'description' => $carousel_color['description'], 'pyme',
                    'section' => 'sec_carousel' . $i,
                    'settings' => $carousel_color['slug'],
                    'priority' => $sec_carousel_control_priority
                )
            )
        );

        $sec_carousel_control_priority++;
    }

    unset($carousel_colors);

    // Slide title text alignment

    $wp_customize->add_setting(
        'set_carousel_title_alignment' . $i,
        array(
            'type' => 'theme_mod',
            'default' => 2,
            'sanitize_callback' => 'pyme_sanitize_select'
        )
    );

    $wp_customize->add_control(
        'set_carousel_title_alignment' . $i,
        array(
            'label' => __('Alineación del texto del título', 'pyme'),
            'description' => __('Seleccione la alineación del texto del título', 'pyme'),
            'section' => 'sec_carousel' . $i,
            'type' => 'select',
            'choices' => array(
                '0' => __('Izquierda', 'pyme'),
                '1' => __('Derecha', 'pyme'),
                '2' => __('Centrado', 'pyme')
            ),
            'priority' => $sec_carousel_control_priority
        )
    );

    $sec_carousel_control_priority++;

    // Field 10 - Slide subtitle text alignment

    $wp_customize->add_setting(
        'set_carousel_subtitle_alignment' . $i,
        array(
            'type' => 'theme_mod',
            'default' => 2,
            'sanitize_callback' => 'pyme_sanitize_select'
        )
    );

    $wp_customize->add_control(
        'set_carousel_subtitle_alignment' . $i,
        array(
            'label' => __('Alineación del texto del subtítulo', 'pyme'),
            'description' => __('Seleccione la alineación del texto del subtítulo', 'pyme'),
            'section' => 'sec_carousel' . $i,
            'type' => 'select',
            'choices' => array(
                '0' => __('Izquierda', 'pyme'),
                '1' => __('Derecha', 'pyme'),
                '2' => __('Centrado', 'pyme')
            ),
            'priority' => $sec_carousel_control_priority
        )
    );

    $sec_carousel_control_priority++;

    // Field 11 - Slide button alignment

    $wp_customize->add_setting(
        'set_carousel_button_alignment' . $i,
        array(
            'type' => 'theme_mod',
            'default' => 2,
            'sanitize_callback' => 'pyme_sanitize_select'
        )
    );

    $wp_customize->add_control(
        'set_carousel_button_alignment' . $i,
        array(
            'label' => __('Alineación del botón', 'pyme'),
            'description' => __('Seleccione la alineación del botón', 'pyme'),
            'section' => 'sec_carousel' . $i,
            'type' => 'select',
            'choices' => array(
                '0' => __('Izquierda', 'pyme'),
                '1' => __('Derecha', 'pyme'),
                '2' => __('Centrado', 'pyme')
            ),
            'priority' => $sec_carousel_control_priority
        )
    );

    $sec_carousel_control_priority++;
}
