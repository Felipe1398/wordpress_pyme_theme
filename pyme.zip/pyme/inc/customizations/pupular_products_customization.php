<?php

// Popular products section

$wp_customize->add_section(
    'sec_popular_products',
    array(
        'title' => __('Configuración de productos populares', 'pyme'),
        'description' => __('Configure la información que se muestra en la sección de productos populares en la página de inicio', 'pyme'),
        'priority' => 1004
    )
);

// Popular products section title

$wp_customize->add_setting(
    'set_popular_products_title',
    array(
        'type' => 'theme_mod',
        'default' => __('Productos populares', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_popular_products_title',
    array(
        'label' => __('Título de la sección', 'pyme'),
        'description' => __('Ingrese el título de la sección', 'pyme'),
        'section' => 'sec_popular_products',
        'type' => 'text',
        'priority' => 1
    )
);

// Popular products section title alignment

$wp_customize->add_setting(
    'set_popular_products_title_alignment',
    array(
        'type' => 'theme_mod',
        'default' => 2,
        'sanitize_callback' => 'pyme_sanitize_select'
    )
);

$wp_customize->add_control(
    'set_popular_products_title_alignment',
    array(
        'label' => __('Alineación del texto del título', 'pyme'),
        'description' => __('Seleccione la alineación del texto del título', 'pyme'),
        'section' => 'sec_popular_products',
        'type' => 'select',
        'choices' => array(
            '0' => __('Izquierda', 'pyme'),
            '1' => __('Derecha', 'pyme'),
            '2' => __('Centrado', 'pyme')
        ),
        'priority' => 2
    )
);

// Popular products section title text color

$wp_customize->add_setting(
    'set_popular_products_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_popular_products_title_color',
        array(
            'label' => __('Color del título', 'pyme'),
            'description' => __('Seleccione el color del texto del título', 'pyme'),
            'section' => 'sec_popular_products',
            'priority' => 3
        )
    )
);

// Popular products section subtitle

$wp_customize->add_setting(
    'set_popular_products_subtitle',
    array(
        'type' => 'theme_mod',
        'default' => __('Visita nuestra tienda y encuentra más productos como estos', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_popular_products_subtitle',
    array(
        'label' => __('Subtítulo de la sección', 'pyme'),
        'description' => __('Ingrese el Subtítulo de la sección', 'pyme'),
        'section' => 'sec_popular_products',
        'type' => 'text',
        'priority' => 4
    )
);

// Popular products section subtitle text alignment

$wp_customize->add_setting(
    'set_popular_products_subtitle_alignment',
    array(
        'type' => 'theme_mod',
        'default' => 2,
        'sanitize_callback' => 'pyme_sanitize_select'
    )
);

$wp_customize->add_control(
    'set_popular_products_subtitle_alignment',
    array(
        'label' => __('Alineación del texto del subtítulo', 'pyme'),
        'description' => __('Seleccione la alineación del texto del subtítulo', 'pyme'),
        'section' => 'sec_popular_products',
        'type' => 'select',
        'choices' => array(
            '0' => __('Izquierda', 'pyme'),
            '1' => __('Derecha', 'pyme'),
            '2' => __('Centrado', 'pyme')
        ),
        'priority' => 5
    )
);

// Popular products section subtitle text color

$wp_customize->add_setting(
    'set_popular_products_subtitle_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_popular_products_subtitle_color',
        array(
            'label' => __('Color del subtítulo', 'pyme'),
            'description' => __('Seleccione el color del texto del subtítulo', 'pyme'),
            'section' => 'sec_popular_products',
            'priority' => 6
        )
    )
);

// Number of popular products to display

$wp_customize->add_setting(
    'set_num_popular_products',
    array(
        'type' => 'theme_mod',
        'default' => 0,
        'sanitize_callback' => 'absint'
    )
);

$wp_customize->add_control(
    'set_num_popular_products',
    array(
        'label' => __('Número de productos a mostrar', 'pyme'),
        'description' => __('Ingrese la cantidad de productos que se mostrarán', 'pyme'),
        'section' => 'sec_popular_products',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 0,
            'max' => 10
        ),
        'priority' => 7
    )
);
