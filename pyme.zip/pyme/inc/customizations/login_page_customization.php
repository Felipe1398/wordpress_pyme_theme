<?php

// Login page section

$wp_customize->add_section(
    'sec_login_customization',
    array(
        'title' => __('Configuración de la página de login', 'pyme'),
        'priority' => 1013
    )
);

// Page color

$wp_customize->add_setting(
    'set_login_primary_color',
    array(
        'type' => 'theme_mod',
        'default' => '#000000',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_login_primary_color',
        array(
            'label' => __('Color principal de la página de login/registro', 'pyme'),
            'description' => __('Color para acentuar textos, bordes, botones, etc... de la página de "login/registro"', 'pyme'),
            'section' => 'sec_login_customization',
            'priority' => 1
        )
    )
);
