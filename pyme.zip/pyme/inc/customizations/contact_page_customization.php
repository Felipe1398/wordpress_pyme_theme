<?php

// Contact page section

$wp_customize->add_section(
    'sec_contact_info',
    array(
        'title' => __('Configuración de la página de "Contacto"', 'pyme'),
        'description' => __('Agregue la información que se muestra en la página de contacto', 'pyme'),
        'priority' => 1011
    )
);

// Contact info section title

$wp_customize->add_setting(
    'set_contact_info_title',
    array(
        'type' => 'theme_mod',
        'default' => __('Contactanos', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_contact_info_title',
    array(
        'label' => __('Título de la sección de información de contacto', 'pyme'),
        'description' => __('Escriba el título de la sección de "información de contacto"', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'text',
        'priority' => 1
    )
);

// Section title text color

$wp_customize->add_setting(
    'set_contact_info_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_contact_info_title_color',
        array(
            'label' => __('Color del título', 'pyme'),
            'description' => __('Seleccione el color del título', 'pyme'),
            'section' => 'sec_contact_info',
            'priority' => 2
        )
    )
);

// Contact info section subtitle

$wp_customize->add_setting(
    'set_contact_info_subtitle',
    array(
        'type' => 'theme_mod',
        'default' => __('Contactanos para obtener más información', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_contact_info_subtitle',
    array(
        'label' => __('Subtítulo de la sección de información de contacto', 'pyme'),
        'description' => __('Escriba el subtítulo de la sección de "información de contacto"', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'text',
        'priority' => 3
    )
);

// Section subtitle text color

$wp_customize->add_setting(
    'set_contact_info_subtitle_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_contact_info_subtitle_color',
        array(
            'label' => __('Color del subtítulo', 'pyme'),
            'description' => __('Seleccione el color del subtítulo', 'pyme'),
            'section' => 'sec_contact_info',
            'priority' => 4
        )
    )
);

// Section background color

$wp_customize->add_setting(
    'set_contact_info_bk_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_contact_info_bk_color',
        array(
            'label' => __('Color de fondo', 'pyme'),
            'description' => __('Seleccione el color de fondo', 'pyme'),
            'section' => 'sec_contact_info',
            'priority' => 5
        )
    )
);

// Social networks section title

$wp_customize->add_setting(
    'set_social_networks_title',
    array(
        'type' => 'theme_mod',
        'default' => __('Nuestras redes sociales', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_social_networks_title',
    array(
        'label' => __('Título de la sección de redes sociales', 'pyme'),
        'description' => __('Escriba el título de la sección de "redes sociales"', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'text',
        'priority' => 6
    )
);

// Section title text color

$wp_customize->add_setting(
    'set_social_networks_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_social_networks_title_color',
        array(
            'label' => __('Color del título', 'pyme'),
            'description' => __('Seleccione el color del texto del título', 'pyme'),
            'section' => 'sec_contact_info',
            'priority' => 7
        )
    )
);

// Social networks section subtitle

$wp_customize->add_setting(
    'set_social_networks_subtitle',
    array(
        'type' => 'theme_mod',
        'default' => __('Visita nuestras redes sociales', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_social_networks_subtitle',
    array(
        'label' => __('Subtítulo de la sección de redes sociales', 'pyme'),
        'description' => __('Escriba el subtítulo de la sección de "redes sociales"', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'text',
        'priority' => 8
    )
);

// Section subtitle text color

$wp_customize->add_setting(
    'set_social_networks_subtitle_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_social_networks_subtitle_color',
        array(
            'label' => __('Color del subtítulo', 'pyme'),
            'description' => __('Seleccione el color del texto del subtítulo', 'pyme'),
            'section' => 'sec_contact_info',
            'priority' => 9
        )
    )
);

// Social network icons color

$wp_customize->add_setting(
    'set_social_network_icons_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_social_network_icons_color',
        array(
            'label' => __('Color de iconos', 'pyme'),
            'description' => __('Seleccione el color de los iconos de las redes sociales', 'pyme'),
            'section' => 'sec_contact_info',
            'priority' => 10
        )
    )
);

// Social network card background color

$wp_customize->add_setting(
    'set_social_networks_bk_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_social_networks_bk_color',
        array(
            'label' => __('Color de fondo', 'pyme'),
            'description' => __('Seleccione el color de fondo de las tarjetas', 'pyme'),
            'section' => 'sec_contact_info',
            'priority' => 11
        )
    )
);

// Contact phone 1

$wp_customize->add_setting(
    'set_contact_phone_1',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_contact_phone_1',
    array(
        'label' => __('Número de teléfono 1', 'pyme'),
        'description' => __('Escriba el número de telefono 1', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'text',
        'priority' => 12
    )
);

// Contact phone 2

$wp_customize->add_setting(
    'set_contact_phone_2',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_contact_phone_2',
    array(
        'label' => __('Número de teléfono 2', 'pyme'),
        'description' => __('Escriba el número de telefono 2', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'text',
        'priority' => 13
    )
);

// Field 10 - Contact phone 3

$wp_customize->add_setting(
    'set_contact_phone_3',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_contact_phone_3',
    array(
        'label' => __('Número de teléfono 3', 'pyme'),
        'description' => __('Escriba el número de telefono 3', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'text',
        'priority' => 14
    )
);

// Field 11 - Link to Whatsapp profile

$wp_customize->add_setting(
    'set_contact_whatsapp',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'esc_url_raw'
    )
);

$wp_customize->add_control(
    'set_contact_whatsapp',
    array(
        'label' => __('Cuenta de Whatsapp', 'pyme'),
        'description' => __('Escriba el enlace al perfil de Whatsapp', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'url',
        'priority' => 15
    )
);

// Field 12 - Link to Insta profile

$wp_customize->add_setting(
    'set_contact_instagram',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'esc_url_raw'
    )
);

$wp_customize->add_control(
    'set_contact_instagram',
    array(
        'label' => __('Cuenta de Instagram', 'pyme'),
        'description' => __('Escriba el enlace al perfil de Instagram', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'url',
        'priority' => 16
    )
);

// Field 13 - Link to Facebook profile

$wp_customize->add_setting(
    'set_contact_facebook',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'esc_url_raw'
    )
);

$wp_customize->add_control(
    'set_contact_facebook',
    array(
        'label' => __('Cuenta de Facebook', 'pyme'),
        'description' => __('Escriba el enlace al perfil de Facebook', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'url',
        'priority' => 17
    )
);

// Field 14 - Link to Twitter profile

$wp_customize->add_setting(
    'set_contact_twitter',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'esc_url_raw'
    )
);

$wp_customize->add_control(
    'set_contact_twitter',
    array(
        'label' => __('Cuenta de Twitter', 'pyme'),
        'description' => __('Escriba el enlace al perfil de Twitter', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'url',
        'priority' => 18
    )
);

// Field 15 - Link to Youtube profile

$wp_customize->add_setting(
    'set_contact_youtube',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'esc_url_raw'
    )
);

$wp_customize->add_control(
    'set_contact_youtube',
    array(
        'label' => __('Cuenta de Youtube', 'pyme'),
        'description' => __('Escriba el enlace al perfil de Youtube', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'url',
        'priority' => 19
    )
);

// Field 16 - Link to Pinterest profile

$wp_customize->add_setting(
    'set_contact_pinterest',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'esc_url_raw'
    )
);

$wp_customize->add_control(
    'set_contact_pinterest',
    array(
        'label' => __('Cuenta de Pinterest', 'pyme'),
        'description' => __('Escriba el enlace al perfil de Pinterest', 'pyme'),
        'section' => 'sec_contact_info',
        'type' => 'url',
        'priority' => 20
    )
);
