<?php

//About section

$wp_customize->add_section(
    'sec_about',
    array(
        'title' => __('Configuración de información acerca de la empresa', 'pyme'),
        'description' => __('Configure la información que se muestra en la sección "acerca de la empresa" que se muestra en la página de inicio', 'pyme'),
        'priority' => 1005
    )
);

//Section title

$wp_customize->add_setting(
    'set_about_title',
    array(
        'type' => 'theme_mod',
        'default' => __('Acerca de nosotras', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_title',
    array(
        'label' => __('Título de la sección', 'pyme'),
        'description' => __('Ingrese el título de la sección', 'pyme'),
        'section' => 'sec_about',
        'type' => 'text',
        'priority' => 1
    )
);

//Section title alignment

$wp_customize->add_setting(
    'set_about_title_alignment',
    array(
        'type' => 'theme_mod',
        'default' => 2,
        'sanitize_callback' => 'pyme_sanitize_select'
    )
);

$wp_customize->add_control(
    'set_about_title_alignment',
    array(
        'label' => __('Alineación del texto del título', 'pyme'),
        'description' => __('Seleccione la alineación del texto del título', 'pyme'),
        'section' => 'sec_about',
        'type' => 'select',
        'choices' => array(
            '0' => __('Izquierda', 'pyme'),
            '1' => __('Derecha', 'pyme'),
            '2' => __('Centrado', 'pyme')
        ),
        'priority' => 2
    )
);

//Section title text color

$wp_customize->add_setting(
    'set_about_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_title_color',
        array(
            'label' => __('Color del texto del título', 'pyme'),
            'description' => __('Seleccione el color del texto del título', 'pyme'),
            'section' => 'sec_about',
            'priority' => 3
        )
    )
);

//Section subtitle

$wp_customize->add_setting(
    'set_about_subtitle',
    array(
        'type' => 'theme_mod',
        'default' => __('¿Quienes somos?', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_subtitle',
    array(
        'label' => __('Subtítulo de la sección', 'pyme'),
        'description' => __('Ingrese el subtítulo de la sección', 'pyme'),
        'section' => 'sec_about',
        'type' => 'text',
        'priority' => 4
    )
);


//Section subtitle alignment

$wp_customize->add_setting(
    'set_about_subtitle_alignment',
    array(
        'type' => 'theme_mod',
        'default' => 2,
        'sanitize_callback' => 'pyme_sanitize_select'
    )
);

$wp_customize->add_control(
    'set_about_subtitle_alignment',
    array(
        'label' => __('Alineación del texto del subtítulo', 'pyme'),
        'description' => __('Seleccione la alineación del texto del subtítulo', 'pyme'),
        'section' => 'sec_about',
        'type' => 'select',
        'choices' => array(
            '0' => __('Izquierda', 'pyme'),
            '1' => __('Derecha', 'pyme'),
            '2' => __('Centrado', 'pyme')
        ),
        'priority' => 5
    )
);

//Section subtitle text color

$wp_customize->add_setting(
    'set_about_subtitle_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_subtitle_color',
        array(
            'label' => __('Color del texto del subtítulo', 'pyme'),
            'description' => __('Seleccione el color del texto del subtítulo', 'pyme'),
            'section' => 'sec_about',
            'priority' => 6
        )
    )
);

//Section description (about company)

$wp_customize->add_setting(
    'set_about_description',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_description',
    array(
        'label' => __('Acerca de la empresa', 'pyme'),
        'description' => __('Ingrese una pequeña descripción acerca de la empresa', 'pyme'),
        'section' => 'sec_about',
        'type' => 'textarea',
        'priority' => 7
    )
);

//Section description alignment

$wp_customize->add_setting(
    'set_about_description_alignment',
    array(
        'type' => 'theme_mod',
        'default' => 3,
        'sanitize_callback' => 'pyme_sanitize_select'
    )
);

$wp_customize->add_control(
    'set_about_description_alignment',
    array(
        'label' => __('Alineación del texto acerca de la empresa', 'pyme'),
        'description' => __('Seleccione la alineación del texto acerca de la empresa', 'pyme'),
        'section' => 'sec_about',
        'type' => 'select',
        'choices' => array(
            '0' => __('Izquierda', 'pyme'),
            '1' => __('Derecha', 'pyme'),
            '2' => __('Centrado', 'pyme'),
            '3' => __('Justificado', 'pyme')
        ),
        'priority' => 8
    )
);

//Section description text color

$wp_customize->add_setting(
    'set_about_description_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_description_color',
        array(
            'label' => __('Color del texto acerca de la empresa', 'pyme'),
            'description' => __('Seleccione el color del texto acerca de la empresa', 'pyme'),
            'section' => 'sec_about',
            'priority' => 9
        )
    )
);

//Field 10 - Number of slides for carousel

$wp_customize->add_setting(
    'set_about_num_slides',
    array(
        'type' => 'theme_mod',
        'default' => 0,
        'sanitize_callback' => 'absint'
    )
);

$wp_customize->add_control(
    'set_about_num_slides',
    array(
        'label' => __('Número de slides del carrusel', 'pyme'),
        'description' => __('Seleccione el número de slides a mostrar en el carrusel. IMPORTANTE: DEBE APLICAR LOS CAMBIOS Y REFRESCAR ESTA PÁGINA PARA QUE ESTE CAMBIO SURTA EFECTO.', 'pyme'),
        'section' => 'sec_about',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 0,
            'max' => 10
        ),
        'priority' => 10
    )
);

//Field 11 - Carousel controls color

$wp_customize->add_setting(
    'set_about_carousel_controls_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_carousel_controls_color',
        array(
            'label' => __('Color de los controles del carousel', 'pyme'),
            'description' => __('Seleccione el color de los controles del carrusel', 'pyme'),
            'section' => 'sec_about',
            'priority' => 11
        )
    )
);


$num_slides = get_theme_mod('set_about_num_slides', 0);
$sec_about_control_priority = 12;

//Field 12 - For each slide in the carousel create a control for that slide's image

for ($i = 1; $i <= $num_slides; $i++) {

    $wp_customize->add_setting(
        'set_slide_img' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'esc_url_raw'
        )
    );

    $wp_customize->add_control(new WP_Customize_Image_Control(
        $wp_customize,
        'set_slide_img' . $i,
        array(
            'label'    => __('Imagen', 'pyme') . ' ' . $i . ' ' . __('del carrusel', 'pyme'),
            'description' => __('Seleccione una imagen', 'pyme'),
            'section'  => 'sec_about',
            'priority' => $sec_about_control_priority
        )
    ));

    $sec_about_control_priority++;
}
