<?php

//Account page section

$wp_customize->add_section(
    'sec_account_customization',
    array(
        'title' => __('Configuración de la página de información de la cuenta', 'pyme'),
        'description' => __('Configure la información que se muestra en la página "Mi cuenta"', 'pyme'),
        'priority' => 1012
    )
);

//Page color

$wp_customize->add_setting(
    'set_account_primary_color',
    array(
        'type' => 'theme_mod',
        'default' => '#000000',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_account_primary_color',
        array(
            'label' => __('Color principal de la página de información de la cuenta', 'pyme'),
            'description' => __('Color para acentuar textos, bordes, botones, etc... de la página de "Mi cuenta"', 'pyme'),
            'section' => 'sec_account_customization',
            'priority' => 1
        )
    )
);
