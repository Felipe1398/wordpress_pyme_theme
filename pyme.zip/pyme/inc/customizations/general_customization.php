<?php

// General config section

$wp_customize->add_section(
    'sec_general_customization',
    array(
        'title' => __('Configuración general', 'pyme'),
        'description' => __('Ajustes generales para todo el sitio', 'pyme'),
        'priority' => 1000
    )
);

// Enable o disable animations

$wp_customize->add_setting(
    'set_animations_enable',
    array(
        'type' => 'theme_mod',
        'default' => true,
        'sanitize_callback' => 'pyme_sanitize_checkbox'
    )
);

$wp_customize->add_control(
    'set_animations_enable',
    array(
        'label' => __('Habilitar animaciones del sitio', 'pyme'),
        'description' => __('Permite que el sitio cargue las animaciones', 'pyme'),
        'section' => 'sec_general_customization',
        'type'  => 'checkbox',
        'priority' => 1
    )
);

// Enable o disable animations on mobile devices

$wp_customize->add_setting(
    'set_mobile_animations_enable',
    array(
        'type' => 'theme_mod',
        'default' => true,
        'sanitize_callback' => 'pyme_sanitize_checkbox'
    )
);

$wp_customize->add_control(
    'set_mobile_animations_enable',
    array(
        'label' => __('Habilitar animaciones del sitio en dispositivos móviles', 'pyme'),
        'description' => __('Permite que el sitio cargue las animaciones en dispositivos móviles', 'pyme'),
        'section' => 'sec_general_customization',
        'type'  => 'checkbox',
        'priority' => 2
    )
);

// Enable o disable extended header

$wp_customize->add_setting(
    'set_extended_header',
    array(
        'type' => 'theme_mod',
        'default' => true,
        'sanitize_callback' => 'pyme_sanitize_checkbox'
    )
);

$wp_customize->add_control(
    'set_extended_header',
    array(
        'label' => __('Habilitar encabezado extendido', 'pyme'),
        'description' => __('El logo del sitio se posiciona sobre la barra de busqueda', 'pyme'),
        'section' => 'sec_general_customization',
        'type'  => 'checkbox',
        'priority' => 3
    )
);

// Enable o disable page title section border

$wp_customize->add_setting(
    'set_border_enable',
    array(
        'type' => 'theme_mod',
        'default' => false,
        'sanitize_callback' => 'pyme_sanitize_checkbox'
    )
);

$wp_customize->add_control(
    'set_border_enable',
    array(
        'label' => __('Habilitar borde en la sección de los títulos', 'pyme'),
        'description' => __('Añade un borde curvo en la parte inferior de la sección de los títulos de cada página', 'pyme'),
        'section' => 'sec_general_customization',
        'type'  => 'checkbox',
        'priority' => 4
    )
);

// Enable o disable page title section shadowing

$wp_customize->add_setting(
    'set_border_shadow_enable',
    array(
        'type' => 'theme_mod',
        'default' => false,
        'sanitize_callback' => 'pyme_sanitize_checkbox'
    )
);

$wp_customize->add_control(
    'set_border_shadow_enable',
    array(
        'label' => __('Habilitar sombreado del borde en la sección de los títulos', 'pyme'),
        'description' => __('Añade un sombreado en el borde inferior de la sección de los títulos de cada página', 'pyme'),
        'section' => 'sec_general_customization',
        'type'  => 'checkbox',
        'priority' => 5
    )
);
