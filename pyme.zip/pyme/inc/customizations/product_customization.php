<?php

// Products section

$wp_customize->add_section(
    'sec_product',
    array(
        'title' => __('Configuración de presentación de los productos', 'pyme'),
        'description' => __('Configure la forma como lucen los productos del sitio en la página de la tienda y en la sección de "productos populares" de la página inicio', 'pyme'),
        'priority' => 1008
    )
);

// Text color

$wp_customize->add_setting(
    'set_product_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_product_color',
        array(
            'label' => __('Color del texto', 'pyme'),
            'description' => __('Seleccione el color del texto del los productos', 'pyme'),
            'section' => 'sec_product',
            'priority' => 1
        )
    )
);

// Products card bacground color

$wp_customize->add_setting(
    'set_product_background',
    array(
        'type' => 'theme_mod',
        'default' => '#f2f2f2',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_product_background',
        array(
            'label' => __('Color de fondo', 'pyme'),
            'description' => __('Seleccione el color de fondo', 'pyme'),
            'section' => 'sec_product',
            'priority' => 2
        )
    )
);

// Product buttons background

$wp_customize->add_setting(
    'set_product_btn_background',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_product_btn_background',
        array(
            'label' => __('Color de fondo de los botones', 'pyme'),
            'description' => __('Seleccione el color de fondo de los botones', 'pyme'),
            'section' => 'sec_product',
            'priority' => 3
        )
    )
);

// Product button texts color

$wp_customize->add_setting(
    'set_product_btn_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_product_btn_color',
        array(
            'label' => __('Color del texto de los botones', 'pyme'),
            'description' => __('Seleccione el color del texto de los botones', 'pyme'),
            'section' => 'sec_product',
            'priority' => 4
        )
    )
);

// Onsale tag background

$wp_customize->add_setting(
    'set_onsale_tag_background',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_onsale_tag_background',
        array(
            'label' => __('Color de fondo de la etiqueta de "oferta"', 'pyme'),
            'description' => __('Seleccione el color de fondo de la etiqueta de "oferta"', 'pyme'),
            'section' => 'sec_product',
            'priority' => 5
        )
    )
);

// Onsale tag text color

$wp_customize->add_setting(
    'set_onsale_tag_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_onsale_tag_color',
        array(
            'label' => __('Color de texto de la etiqueta de "oferta"', 'pyme'),
            'description' => __('Seleccione el color del texto de la etiqueta de "oferta"', 'pyme'),
            'section' => 'sec_product',
            'priority' => 6
        )
    )
);

// Product cards border color

$wp_customize->add_setting(
    'set_product_border',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_product_border',
        array(
            'label' => __('Color de borde', 'pyme'),
            'description' => __('Seleccione el color del borde', 'pyme'),
            'section' => 'sec_product',
            'priority' => 7
        )
    )
);
