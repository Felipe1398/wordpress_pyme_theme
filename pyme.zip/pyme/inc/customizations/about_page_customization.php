<?php

//Panel for about page customuzations

$wp_customize->add_panel('company_info_panel', array(
    'title' => __('Configuración de la página "Acerca de"', 'pyme'),
    'description' => __('Configure la información que se muestra en la página "Acerca de"', 'pyme'),
    'priority' => 1010
));

//About team section

$wp_customize->add_section(
    'sec_about_team',
    array(
        'title' => __('Configuración de información acerca de los principales miembros de la empresa', 'pyme'),
        'description' => __('Agregue la información de los miembros del equipo', 'pyme'),
        'panel' => 'company_info_panel'
    )
);

//Section title

$wp_customize->add_setting(
    'set_about_team_section_title',
    array(
        'type' => 'theme_mod',
        'default' => __('Conoce nuestro equipo', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_team_section_title',
    array(
        'label' => __('Título de la sección', 'pyme'),
        'description' => __('Escriba el título de la sección', 'pyme'),
        'section' => 'sec_about_team',
        'type' => 'text',
        'priority' => 1
    )
);

//Section title text color

$wp_customize->add_setting(
    'set_about_team_section_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_team_section_title_color',
        array(
            'label' => __('Color del título', 'pyme'),
            'description' => __('Seleccione el color del texto del título', 'pyme'),
            'section' => 'sec_about_team',
            'priority' => 2
        )
    )
);

//Section subtitle

$wp_customize->add_setting(
    'set_about_team_section_subtitle',
    array(
        'type' => 'theme_mod',
        'default' => __('Conoce nuestro equipo', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_team_section_subtitle',
    array(
        'label' => __('Subtítulo de la sección', 'pyme'),
        'description' => __('Escriba el subtítulo de la sección', 'pyme'),
        'section' => 'sec_about_team',
        'type' => 'text',
        'priority' => 3
    )
);

//Section subtitle text color

$wp_customize->add_setting(
    'set_about_team_section_subtitle_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_team_section_subtitle_color',
        array(
            'label' => __('Color del subtítulo', 'pyme'),
            'description' => __('Seleccione el color del texto del subtítulo', 'pyme'),
            'section' => 'sec_about_team',
            'priority' => 4
        )
    )
);

//Section background color

$wp_customize->add_setting(
    'set_about_team_section_bk_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_team_section_bk_color',
        array(
            'label' => __('Color de fondo', 'pyme'),
            'description' => __('Seleccione el color de fondo', 'pyme'),
            'section' => 'sec_about_team',
            'priority' => 5
        )
    )
);

//Section text color

$wp_customize->add_setting(
    'set_about_team_section_txt_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_team_section_txt_color',
        array(
            'label' => __('Color del nombre del colaborador', 'pyme'),
            'description' => __('Seleccione el color del texto del nombre del colaborador', 'pyme'),
            'section' => 'sec_about_team',
            'priority' => 6
        )
    )
);

//Section button background color

$wp_customize->add_setting(
    'set_about_team_section_btn_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_team_section_btn_color',
        array(
            'label' => __('Color del botón', 'pyme'),
            'description' => __('Seleccione el color de fondo del botón', 'pyme'),
            'section' => 'sec_about_team',
            'priority' => 7
        )
    )
);

//Section button text color

$wp_customize->add_setting(
    'set_about_team_section_btn_txt_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_team_section_btn_txt_color',
        array(
            'label' => __('Color del texto del botón', 'pyme'),
            'description' => __('Seleccione el color del texto del botón', 'pyme'),
            'section' => 'sec_about_team',
            'priority' => 8
        )
    )
);

//Section border color

$wp_customize->add_setting(
    'set_about_team_section_border_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_team_section_border_color',
        array(
            'label' => __('Color del borde de la tarjeta', 'pyme'),
            'description' => __('Seleccione el color del del borde', 'pyme'),
            'section' => 'sec_about_team',
            'priority' => 9
        )
    )
);

//Number of teams members

$wp_customize->add_setting(
    'set_num_team_members',
    array(
        'type' => 'theme_mod',
        'default' => 0,
        'sanitize_callback' => 'absint'
    )
);

$wp_customize->add_control(
    'set_num_team_members',
    array(
        'label' => __('Número de miembros del equipo', 'pyme'),
        'description' => __('Seleccione el número de miembros del equipo que se mostrarán. IMPORTANTE: DEBE APLICAR LOS CAMBIOS Y REFRESCAR ESTA PÁGINA PARA QUE ESTE CAMBIO SURTA EFECTO.', 'pyme'),
        'section' => 'sec_about_team',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100
        ),
        'priority' => 10
    )
);

//For each team member, create a control for the person's photo, name and biography

$num_members = get_theme_mod('set_num_team_members', 0);
$sec_about_team_control_priority = 11;

for ($i = 1; $i <= $num_members; $i++) {


    $wp_customize->add_setting(
        'set_member_photo' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'esc_url_raw'
        )
    );

    $wp_customize->add_control(new WP_Customize_Image_Control(
        $wp_customize,
        'set_member_photo' . $i,
        array(
            'label'    => __('Fotografía de la persona', 'pyme') . ' ' . $i,
            'description' => __('Seleccione una foto', 'pyme'),
            'section'  => 'sec_about_team',
            'priority' => $sec_about_team_control_priority
        )
    ));

    $sec_about_team_control_priority++;

    $wp_customize->add_setting(
        'set_member_name' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_member_name' . $i,
        array(
            'label' => __('Nombre de la persona', 'pyme') . ' ' . $i,
            'description' => __('Escriba el nombre de la persona', 'pyme'),
            'section' => 'sec_about_team',
            'type' => 'text',
            'priority' => $sec_about_team_control_priority
        )
    );

    $sec_about_team_control_priority++;

    $wp_customize->add_setting(
        'set_member_bio' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_member_bio' . $i,
        array(
            'label' => __('Biografía de la persona', 'pyme') . ' ' . $i,
            'description' => __('Escriba una pequeña biografía acerca de la persona', 'pyme'),
            'section' => 'sec_about_team',
            'type' => 'textarea',
            'priority' => $sec_about_team_control_priority
        )
    );

    $sec_about_team_control_priority++;
}

//About company section

$wp_customize->add_section(
    'sec_about_company',
    array(
        'title' => __('Configuración de información acerca de la empresa', 'pyme'),
        'description' => __('Configure la información de la empresa que se muestra en la página de "acerca de"', 'pyme'),
        'panel' => 'company_info_panel'
    )
);

//Section title

$wp_customize->add_setting(
    'set_about_company_section_title',
    array(
        'type' => 'theme_mod',
        'default' => __('Conoce nuestra historia', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_company_section_title',
    array(
        'label' => __('Título de la sección', 'pyme'),
        'description' => __('Escriba el título de la sección', 'pyme'),
        'section' => 'sec_about_company',
        'type' => 'text',
        'priority' => 1
    )
);

//Section title color

$wp_customize->add_setting(
    'set_about_company_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_company_title_color',
        array(
            'label' => __('Color del título', 'pyme'),
            'description' => __('Seleccione el color del título', 'pyme'),
            'section' => 'sec_about_company',
            'priority' => 2
        )
    )
);

//Section subtitle

$wp_customize->add_setting(
    'set_about_company_section_subtitle',
    array(
        'type' => 'theme_mod',
        'default' => __('Conoce más sobre nosotras', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_company_section_subtitle',
    array(
        'label' => __('Subtítulo de la sección', 'pyme'),
        'description' => __('Escriba el subtítulo de la sección', 'pyme'),
        'section' => 'sec_about_company',
        'type' => 'text',
        'priority' => 3
    )
);

//Section subtitle color

$wp_customize->add_setting(
    'set_about_company_subtitle_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_company_subtitle_color',
        array(
            'label' => __('Color del subtítulo', 'pyme'),
            'description' => __('Seleccione el color del subtítulo', 'pyme'),
            'section' => 'sec_about_company',
            'priority' => 4
        )
    )
);

//Section backgroud

$wp_customize->add_setting(
    'set_about_company_bk_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_company_bk_color',
        array(
            'label' => __('Color del fondo', 'pyme'),
            'description' => __('Seleccione el color de fondo', 'pyme'),
            'section' => 'sec_about_company',
            'priority' => 5
        )
    )
);

//Section text color

$wp_customize->add_setting(
    'set_about_company_txt_color',
    array(
        'type' => 'theme_mod',
        'default' => '#000000',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_company_txt_color',
        array(
            'label' => __('Color del texto', 'pyme'),
            'description' => __('Seleccione el color del texto', 'pyme'),
            'section' => 'sec_about_company',
            'priority' => 6
        )
    )
);

//About products section

$wp_customize->add_section(
    'sec_about_products',
    array(
        'title' => __('Configuración de información acerca de los productos', 'pyme'),
        'description' => __('Configure la información de los productos que se muestra en la página de "acerca de"', 'pyme'),
        'panel' => 'company_info_panel'
    )
);

//Section title

$wp_customize->add_setting(
    'set_about_products_section_title',
    array(
        'type' => 'theme_mod',
        'default' => __('Características de nuestros productos', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_products_section_title',
    array(
        'label' => __('Título de la sección', 'pyme'),
        'description' => __('Escriba el título de la sección', 'pyme'),
        'section' => 'sec_about_products',
        'type' => 'text',
        'priority' => 1
    )
);

//Section title text color

$wp_customize->add_setting(
    'set_about_products_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_products_title_color',
        array(
            'label' => __('Color del título', 'pyme'),
            'description' => __('Seleccione el color del título', 'pyme'),
            'section' => 'sec_about_products',
            'priority' => 2
        )
    )
);

//Section subtitle

$wp_customize->add_setting(
    'set_about_products_section_subtitle',
    array(
        'type' => 'theme_mod',
        'default' => __('¿Que hace especiales a nuestros productos?', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about_products_section_subtitle',
    array(
        'label' => __('Subtítulo de la sección', 'pyme'),
        'description' => __('Escriba el subtítulo de la sección', 'pyme'),
        'section' => 'sec_about_products',
        'type' => 'text',
        'priority' => 3
    )
);

//Section subtitle text color

$wp_customize->add_setting(
    'set_about_products_subtitle_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_products_subtitle_color',
        array(
            'label' => __('Color del subtítulo', 'pyme'),
            'description' => __('Seleccione el color del subtítulo', 'pyme'),
            'section' => 'sec_about_products',
            'priority' => 4
        )
    )
);

//Section background color

$wp_customize->add_setting(
    'set_about_products_card_bk_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_products_card_bk_color',
        array(
            'label' => __('Color del fondo', 'pyme'),
            'description' => __('Seleccione el color de fondo', 'pyme'),
            'section' => 'sec_about_products',
            'priority' => 5
        )
    )
);

//Section feature text color

$wp_customize->add_setting(
    'set_about_products_card_feature_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_products_card_feature_color',
        array(
            'label' => __('Color del texto de la característica de producto', 'pyme'),
            'description' => __('Seleccione el color del texto de la característica', 'pyme'),
            'section' => 'sec_about_products',
            'priority' => 6
        )
    )
);

//Section feature description text color

$wp_customize->add_setting(
    'set_about_products_card_txt_color',
    array(
        'type' => 'theme_mod',
        'default' => '#000000',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_about_products_card_txt_color',
        array(
            'label' => __('Color del texto de la descripción', 'pyme'),
            'description' => __('Seleccione el color del texto de la descripción de la característica', 'pyme'),
            'section' => 'sec_about_products',
            'priority' => 7
        )
    )
);

//Number of features to be displayed

$wp_customize->add_setting(
    'set_num_products_features',
    array(
        'type' => 'theme_mod',
        'default' => 0,
        'sanitize_callback' => 'absint'
    )
);

$wp_customize->add_control(
    'set_num_products_features',
    array(
        'label' => __('Número de características de productos', 'pyme'),
        'description' => __('Escriba el número de características a mostrar. IMPORTANTE: DEBE APLICAR LOS CAMBIOS Y REFRESCAR ESTA PÁGINA PARA QUE ESTE CAMBIO SURTA EFECTO.', 'pyme'),
        'section' => 'sec_about_products',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 0,
            'max' => 10
        ),
        'priority' => 8
    )
);

//For each feature create a control for the image, title and description of the feature

$num_features = get_theme_mod('set_num_products_features', 0);
$sec_about_products_control_priority = 9;

for ($i = 1; $i <= $num_features; $i++) {


    $wp_customize->add_setting(
        'set_product_feature_logo' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'esc_url_raw'
        )
    );

    $wp_customize->add_control(new WP_Customize_Image_Control(
        $wp_customize,
        'set_product_feature_logo' . $i,
        array(
            'label'    => __('Imagen de la característica', 'pyme') . ' ' . $i,
            'description' => __('Seleccione una imagen', 'pyme'),
            'section'  => 'sec_about_products',
            'priority' => $sec_about_products_control_priority
        )
    ));

    $sec_about_products_control_priority++;

    $wp_customize->add_setting(
        'set_product_feature_title' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_product_feature_title' . $i,
        array(
            'label' => __('Título de la característica', 'pyme') . ' ' . $i,
            'description' => __('Escriba un título para esta característica', 'pyme'),
            'section' => 'sec_about_products',
            'type' => 'text',
            'priority' => $sec_about_products_control_priority
        )
    );

    $sec_about_products_control_priority++;

    $wp_customize->add_setting(
        'set_product_feature_description' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_product_feature_description' . $i,
        array(
            'label' => __('Descripción de la característica', 'pyme') . ' ' . $i,
            'description' => __('Describa esta característica', 'pyme'),
            'section' => 'sec_about_products',
            'type' => 'textarea',
            'priority' => $sec_about_products_control_priority
        )
    );

    $sec_about_products_control_priority++;
}
