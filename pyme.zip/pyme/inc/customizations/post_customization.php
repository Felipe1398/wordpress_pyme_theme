<?php

// Posts section

$wp_customize->add_section(
    'sec_post',
    array(
        'title' => __('Configuración de presentación de los articulos', 'pyme'),
        'description' => __('Configure la forma como lucen los articulos del sitio en la página del blog y en la sección de "articulos recientes" de la página inicio', 'pyme'),
        'priority' => 1009
    )
);

// Post title text color

$wp_customize->add_setting(
    'set_post_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_post_title_color',
        array(
            'label' => __('Color del título', 'pyme'),
            'description' => __('Seleccione el color del texto del título de los articulos', 'pyme'),
            'section' => 'sec_post',
            'priority' => 1
        )
    )
);

// Post text color

$wp_customize->add_setting(
    'set_post_txt_color',
    array(
        'type' => 'theme_mod',
        'default' => '#000000',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_post_txt_color',
        array(
            'label' => __('Color del texto', 'pyme'),
            'description' => __('Color del texto de los articulos', 'pyme'),
            'section' => 'sec_post',
            'priority' => 2
        )
    )
);

// Post card background

$wp_customize->add_setting(
    'set_post_background',
    array(
        'type' => 'theme_mod',
        'default' => '#f2f2f2',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_post_background',
        array(
            'label' => __('Color de fondo', 'pyme'),
            'description' => __('Seleccione el color de fondo', 'pyme'),
            'section' => 'sec_post',
            'priority' => 3
        )
    )
);

// Post button background

$wp_customize->add_setting(
    'set_post_btn_background',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_post_btn_background',
        array(
            'label' => __('Color de fondo de los botones', 'pyme'),
            'description' => __('Seleccione el color de fondo de los botones', 'pyme'),
            'section' => 'sec_post',
            'priority' => 4
        )
    )
);

// Post button text background

$wp_customize->add_setting(
    'set_post_btn_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_post_btn_color',
        array(
            'label' => __('Color de texto de los botones', 'pyme'),
            'description' => __('Seleccione el color del texto de los botones', 'pyme'),
            'section' => 'sec_post',
            'priority' => 5
        )
    )
);

// Post date tag background

$wp_customize->add_setting(
    'set_date_tag_background',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_date_tag_background',
        array(
            'label' => __('Color de fondo de la etiqueta de fecha de publicación', 'pyme'),
            'description' => __('Seleccione el color de fondo de la etiqueta con la fecha de publicación', 'pyme'),
            'section' => 'sec_post',
            'priority' => 6
        )
    )
);

// Post date tag text color

$wp_customize->add_setting(
    'set_date_tag_color',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_date_tag_color',
        array(
            'label' => __('Color de texto de la etiqueta de fecha de publicación', 'pyme'),
            'description' => __('Seleccione el color de texto de la etiqueta con la fecha de publicación', 'pyme'),
            'section' => 'sec_post',
            'priority' => 7
        )
    )
);

// Post card border color

$wp_customize->add_setting(
    'set_post_border',
    array(
        'type' => 'theme_mod',
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_post_border',
        array(
            'label' => __('Color de borde', 'pyme'),
            'description' => __('Seleccione el color del borde', 'pyme'),
            'section' => 'sec_post',
            'priority' => 8
        )
    )
);
