<?php

$cat_args = array(
    'orderby'    => 'name',
    'order'      => 'asc',
    'hide_empty' => false,
);

$product_categories = get_terms('product_cat', $cat_args);

if (!empty($product_categories)) {

    //Product categories section

    $wp_customize->add_section(
        'sec_categories',
        array(
            'title' => __('Configuración de categorías de productos', 'pyme'),
            'description' => __('Configure la sección de "categorías de productos" que se muestra en la página de inicio', 'pyme'),
            'priority' => 1006
        )
    );

    //Section title

    $wp_customize->add_setting(
        'set_categories_title',
        array(
            'type' => 'theme_mod',
            'default' => __('Categorías de productos', 'pyme'),
            'sanitize_callback' => 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_categories_title',
        array(
            'label' => __('Título de la sección', 'pyme'),
            'description' => __('Ingrese el título de la sección', 'pyme'),
            'section' => 'sec_categories',
            'type' => 'text',
            'priority' => 1
        )
    );

    //Section title alignment

    $wp_customize->add_setting(
        'set_categories_title_alignment',
        array(
            'type' => 'theme_mod',
            'default' => 2,
            'sanitize_callback' => 'pyme_sanitize_select'
        )
    );

    $wp_customize->add_control(
        'set_categories_title_alignment',
        array(
            'label' => __('Alineación del texto del título', 'pyme'),
            'description' => __('Seleccione la alineación del texto del título', 'pyme'),
            'section' => 'sec_categories',
            'type' => 'select',
            'choices' => array(
                '0' => __('Izquierda', 'pyme'),
                '1' => __('Derecha', 'pyme'),
                '2' => __('Centrado', 'pyme')
            ),
            'priority' => 2
        )
    );

    //Section title color

    $wp_customize->add_setting(
        'set_categories_title_color',
        array(
            'type' => 'theme_mod',
            'default' => get_theme_mod('set_primary_color', '#008037'),
            'sanitize_callback' => 'sanitize_hex_color'
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'set_categories_title_color',
            array(
                'label' => __('Color del título', 'pyme'),
                'description' => __('Ingrese el color del texto de título', 'pyme'),
                'section' => 'sec_categories',
                'priority' => 3
            )
        )
    );

    //Section subtitle

    $wp_customize->add_setting(
        'set_categories_subtitle',
        array(
            'type' => 'theme_mod',
            'default' => __('Visita nuestra tienda y descubre todos nuestros productos', 'pyme'),
            'sanitize_callback' => 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_categories_subtitle',
        array(
            'label' => __('Subtítulo de la sección', 'pyme'),
            'description' => __('Ingrese el subtítulo de la sección', 'pyme'),
            'section' => 'sec_categories',
            'type' => 'text',
            'priority' => 4
        )
    );

    //Section subtitle alignment

    $wp_customize->add_setting(
        'set_categories_subtitle_alignment',
        array(
            'type' => 'theme_mod',
            'default' => 2,
            'sanitize_callback' => 'pyme_sanitize_select'
        )
    );

    $wp_customize->add_control(
        'set_categories_subtitle_alignment',
        array(
            'label' => __('Alineación del texto del subtítulo', 'pyme'),
            'description' => __('Seleccione la alineación del texto del subtítulo', 'pyme'),
            'section' => 'sec_categories',
            'type' => 'select',
            'choices' => array(
                '0' => __('Izquierda', 'pyme'),
                '1' => __('Derecha', 'pyme'),
                '2' => __('Centrado', 'pyme')
            ),
            'priority' => 5
        )
    );

    //Section subtitle text color

    $wp_customize->add_setting(
        'set_categories_subtitle_color',
        array(
            'type' => 'theme_mod',
            'default' => get_theme_mod('set_primary_color', '#008037'),
            'sanitize_callback' => 'sanitize_hex_color'
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'set_categories_subtitle_color',
            array(
                'label' => __('Color del subtítulo', 'pyme'),
                'description' => __('Seleccione el color del texto del subtítulo', 'pyme'),
                'section' => 'sec_categories',
                'priority' => 6
            )
        )
    );

    //Categorie name text color

    $wp_customize->add_setting(
        'set_categories_name_color',
        array(
            'type' => 'theme_mod',
            'default' => get_theme_mod('set_primary_color', '#008037'),
            'sanitize_callback' => 'sanitize_hex_color'
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'set_categories_name_color',
            array(
                'label' => __('Color del texto', 'pyme'),
                'description' => __('Seleccione el color del texto del nombre de las categorías', 'pyme'),
                'section' => 'sec_categories',
                'priority' => 7
            )
        )
    );

    //Categorie background color

    $wp_customize->add_setting(
        'set_categories_background_color',
        array(
            'type' => 'theme_mod',
            'default' => '#ffffff',
            'sanitize_callback' => 'sanitize_hex_color'
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'set_categories_background_color',
            array(
                'label' => __('Color de fondo', 'pyme'),
                'description' => __('Seleccione el color de', 'pyme'),
                'section' => 'sec_categories',
                'priority' => 8
            )
        )
    );

    //For each category, create a control for the logo and visibility

    $sec_categories_control_priority = 8;
    for ($i = 0; $i < count($product_categories); $i++) {

        $wp_customize->add_setting(
            'set_categorie_logo' . ($i + 1),
            array(
                'type' => 'theme_mod',
                'sanitize_callback' => 'esc_url_raw'
            )
        );

        $wp_customize->add_control(new WP_Customize_Image_Control(
            $wp_customize,
            'set_categorie_logo' . ($i + 1),
            array(
                'label'    => __('Logo de la categoría', 'pyme') . ': ' . $product_categories[$i]->name,
                'description' => __('Seleccione una imagen', 'pyme'),
                'section'  => 'sec_categories',
                'priority' => $sec_categories_control_priority
            )
        ));

        $sec_categories_control_priority++;

        $wp_customize->add_setting(
            'set_category_visibility' . ($i + 1),
            array(
                'type' => 'theme_mod',
                'default' => true,
                'sanitize_callback' => 'pyme_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            'set_category_visibility' . ($i + 1),
            array(
                'label' => __('Mostrar categoría', 'pyme'),
                'description' => __('Oculte o muestre la categoría en la sección', 'pyme'),
                'section' => 'sec_categories',
                'type'  => 'checkbox',
                'priority' => $sec_categories_control_priority
            )
        );

        $sec_categories_control_priority++;
    }
}
