<?php

// Footer section

$wp_customize->add_section(
    'sec_footer',
    array(
        'title' => __('Configuración del pie de página', 'pyme'),
        'description' => __('Configure la información que se muestra en el pie de página', 'pyme'),
        'priority' => 1014
    )
);

// About company

$wp_customize->add_setting(
    'set_about',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_about',
    array(
        'label' => __('Acerca de la empresa', 'pyme'),
        'description' => __('Escriba un breve resumen de su empresa', 'pyme'),
        'section' => 'sec_footer',
        'type' => 'textarea',
        'priority' => 1
    )
);

// Main contact number

$wp_customize->add_setting(
    'set_contact_number1',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_contact_number1',
    array(
        'label' => __('Número de teléfono 1', 'pyme'),
        'description' => __('Numero de teléfono principal', 'pyme'),
        'section' => 'sec_footer',
        'type' => 'text',
        'priority' => 2
    )
);

// Other contact number

$wp_customize->add_setting(
    'set_contact_number2',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_contact_number2',
    array(
        'label' => __('Número de teléfono 2', 'pyme'),
        'description' => __('Numero de teléfono secundario', 'pyme'),
        'section' => 'sec_footer',
        'type' => 'text',
        'priority' => 3
    )
);

// Contact email

$wp_customize->add_setting(
    'set_contact_email',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_email'
    )
);

$wp_customize->add_control(
    'set_contact_email',
    array(
        'label' => __('Email', 'pyme'),
        'description' => __('Email de contacto', 'pyme'),
        'section' => 'sec_footer',
        'type' => 'email',
        'priority' => 3
    )
);

// Store address

$wp_customize->add_setting(
    'set_contact_address',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_contact_address',
    array(
        'label' => __('Dirección de la tienda', 'pyme'),
        'description' => __('Ubicación física de la tienda', 'pyme'),
        'section' => 'sec_footer',
        'type' => 'textarea',
        'priority' => 3
    )
);

// Copyright info

$wp_customize->add_setting(
    'set_copyright',
    array(
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_copyright',
    array(
        'label' => __('Copyright', 'pyme'),
        'description' => __('Agregue su información de copyrigth', 'pyme'),
        'section' => 'sec_footer',
        'type' => 'text'
    )
);
