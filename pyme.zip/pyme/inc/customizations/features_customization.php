<?php

// Product features section

$wp_customize->add_section(
    'sec_features',
    array(
        'title' => __('Configuración de cácteristicas de productos', 'pyme'),
        'description' => __('Configure la información que se muestra en la sección de "características de los productos" en la página de incio', 'pyme'),
        'priority' => 1003
    )
);

// Feature title text color

$wp_customize->add_setting(
    'set_feature_texts_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_feature_texts_color',
        array(
            'label' => __('Color de los textos', 'pyme'),
            'description' => __('Seleccione el color del texto del título de la características', 'pyme'),
            'section' => 'sec_features',
            'priority' => 1
        )
    )
);

// Create 4 product features

$sec_features_control_priority = 2;
for ($i = 1; $i <= 4; $i++) {

    // Feature logo

    $wp_customize->add_setting(
        'set_feature_logo' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'esc_url_raw'
        )
    );

    $wp_customize->add_control(new WP_Customize_Image_Control(
        $wp_customize,
        'set_feature_logo' . $i,
        array(
            'label'    => __('Logo de la característica', 'pyme') . ' ' . $i,
            'description' => __('Seleccione una imagen', 'pyme'),
            'section'  => 'sec_features',
            'priority' => $sec_features_control_priority
        )
    ));

    $sec_features_control_priority++;

    // Feature title

    $wp_customize->add_setting(
        'set_feature_text' . $i,
        array(
            'type' => 'theme_mod',
            'sanitize_callback' => 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_feature_text' . $i,
        array(
            'label' => __('Título de la característica', 'pyme') . ' ' . $i,
            'description' => __('Escriba una característica de los productos', 'pyme'),
            'section' => 'sec_features',
            'type' => 'text',
            'priority' => $sec_features_control_priority
        )
    );

    $sec_features_control_priority++;
}
