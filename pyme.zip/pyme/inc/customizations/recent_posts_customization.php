<?php

// Recent posts section

$wp_customize->add_section(
    'sec_recent_posts',
    array(
        'title' => __('Configuración de artículos recientes', 'pyme'),
        'description' => __('Configure la información que se muestra en la sección de "articulos recientes" en la página de inicio', 'pyme'),
        'priority' => 1007
    )
);

// Recent posts section section title

$wp_customize->add_setting(
    'set_recent_posts_title',
    array(
        'type' => 'theme_mod',
        'default' => __('Artículos recientes', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_recent_posts_title',
    array(
        'label' => __('Título de la sección', 'pyme'),
        'description' => __('Ingrese el título de la sección', 'pyme'),
        'section' => 'sec_recent_posts',
        'type' => 'text',
        'priority' => 1
    )
);

// Recent posts section title text alignment

$wp_customize->add_setting(
    'set_recent_posts_title_alignment',
    array(
        'type' => 'theme_mod',
        'default' => 2,
        'sanitize_callback' => 'pyme_sanitize_select'
    )
);

$wp_customize->add_control(
    'set_recent_posts_title_alignment',
    array(
        'label' => __('Alineación del texto del título', 'pyme'),
        'description' => __('Seleccione la alineación del texto del título', 'pyme'),
        'section' => 'sec_recent_posts',
        'type' => 'select',
        'choices' => array(
            '0' => __('Izquierda', 'pyme'),
            '1' => __('Derecha', 'pyme'),
            '2' => __('Centrado', 'pyme')
        ),
        'priority' => 2
    )
);

// Recent posts section title color

$wp_customize->add_setting(
    'set_recent_posts_title_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_recent_posts_title_color',
        array(
            'label' => __('Color del título', 'pyme'),
            'description' => __('Seleccione el color del título', 'pyme'),
            'section' => 'sec_recent_posts',
            'priority' => 3
        )
    )
);

// Recent posts section subtitle

$wp_customize->add_setting(
    'set_recent_posts_subtitle',
    array(
        'type' => 'theme_mod',
        'default' => __('Visita nuestro blog y lee más artículos como estos', 'pyme'),
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_recent_posts_subtitle',
    array(
        'label' => __('Subtítulo de la sección', 'pyme'),
        'description' => __('Ingrese el subtítulo de la sección', 'pyme'),
        'section' => 'sec_recent_posts',
        'type' => 'text',
        'priority' => 4
    )
);

// Recent posts section subtitle alignment

$wp_customize->add_setting(
    'set_recent_posts_subtitle_alignment',
    array(
        'type' => 'theme_mod',
        'default' => 2,
        'sanitize_callback' => 'pyme_sanitize_select'
    )
);

$wp_customize->add_control(
    'set_recent_posts_subtitle_alignment',
    array(
        'label' => __('Alineación del texto del subtítulo', 'pyme'),
        'description' => __('Seleccione la alineación del texto del subtítulo', 'pyme'),
        'section' => 'sec_recent_posts',
        'type' => 'select',
        'choices' => array(
            '0' => __('Izquierda', 'pyme'),
            '1' => __('Derecha', 'pyme'),
            '2' => __('Centrado', 'pyme')
        ),
        'priority' => 5
    )
);

// Recent posts section subtitle color

$wp_customize->add_setting(
    'set_recent_posts_subtitle_color',
    array(
        'type' => 'theme_mod',
        'default' => get_theme_mod('set_primary_color', '#008037'),
        'sanitize_callback' => 'sanitize_hex_color'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'set_recent_posts_subtitle_color',
        array(
            'label' => __('Color del subtítulo', 'pyme'),
            'description' => __('Seleccione el color del subtítulo', 'pyme'),
            'section' => 'sec_recent_posts',
            'priority' => 6
        )
    )
);

// Number of posts to display

$wp_customize->add_setting(
    'set_recent_posts_num',
    array(
        'type' => 'theme_mod',
        'default' => 0,
        'sanitize_callback' => 'absint'
    )
);

$wp_customize->add_control(
    'set_recent_posts_num',
    array(
        'label' => __('Número de artículos', 'pyme'),
        'description' => __('Seleccione el número de artículos a mostrar', 'pyme'),
        'section' => 'sec_recent_posts',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 0,
            'max' => 10
        ),
        'priority' => 7
    )
);
