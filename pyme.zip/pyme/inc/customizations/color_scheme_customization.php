<?php

// Color scheme section

$wp_customize->add_section(
    'sec_color',
    array(
        'title' => __('Esquema de colores', 'pyme'),
        'description' => __('Sección de colores del tema', 'pyme'),
        'priority' => 1001
    )
);

// primary color
$theme_colors[] = array(
    'slug' => 'set_primary_color',
    'default' => '#008037',
    'label' => __('Color principal', 'pyme'),
    'description' => __('Seleccione el color principal del sitio', 'pyme')
);

// secondary color
$theme_colors[] = array(
    'slug' => 'set_secondary_color',
    'default' => '#DBD0C4',
    'label' => __('Color secundario', 'pyme'),
    'description' => __('Seleccione el color secundario del sitio', 'pyme')
);

// svg icons color
$theme_colors[] = array(
    'slug' => 'set_icons_color',
    'default' => '#FFFFFF',
    'label' => __('Color de los iconos', 'pyme'),
    'description' => __('Seleccione el color de los iconos del sitio', 'pyme')
);

// links color

$theme_colors[] = array(
    'slug' => 'set_links_color',
    'default' => get_theme_mod('set_primary_color', '#008037'),
    'label' => __('Color de enlaces', 'pyme'),
    'description' => __('Seleccione el color de los enlaces del sitio', 'pyme')
);

$theme_colors[] = array(
    'slug' => 'set_links_hover_color',
    'default' => get_theme_mod('set_primary_color', '#008037'),
    'label' => __('Color de enlaces al pasar el cursor', 'pyme'),
    'description' => __('Seleccione el color de los enlaces del sitio al posicionar el cursor sobre ellos', 'pyme')
);

// nav links color

$theme_colors[] = array(
    'slug' => 'set_nav_links_color',
    'default' => get_theme_mod('set_primary_color', '#008037'),
    'label' => __('Color de enlaces del menú principal del sitio', 'pyme'),
    'description' => __('Seleccione el color de los enlaces del menú principal del sitio', 'pyme')
);

$theme_colors[] = array(
    'slug' => 'set_nav_links_hover_color',
    'default' => get_theme_mod('set_primary_color', '#008037'),
    'label' => __('Color de enlaces del menú principal del sitio al pasar el cursor', 'pyme'),
    'description' => __('Seleccione el color de los enlaces del menú principal al posicionar el cursor sobre ellos', 'pyme')
);

// footer links color

$theme_colors[] = array(
    'slug' => 'set_footer_links_color',
    'default' => get_theme_mod('set_primary_color', '#008037'),
    'label' => __('Color de enlaces del pie de página', 'pyme'),
    'description' => __('Seleccione el color de los enlaces del pie de página del sitio', 'pyme')
);

$theme_colors[] = array(
    'slug' => 'set_footer_links_hover_color',
    'default' => get_theme_mod('set_primary_color', '#008037'),
    'label' => __('Color de enlaces del del pie de página al pasar el cursor', 'pyme'),
    'description' => __('Seleccione el color de los enlaces del pie de página al posicionar el cursor sobre ellos', 'pyme')
);


// add the settings and controls for each color
foreach ($theme_colors as $theme_color) {

    // SETTINGS
    $wp_customize->add_setting(
        $theme_color['slug'],
        array(
            'type' => 'theme_mod',
            'default' => $theme_color['default'], 'pyme',
            'sanitize_callback' => 'sanitize_hex_color'
        )
    );

    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $theme_color['slug'],
            array(
                'label' => $theme_color['label'], 'pyme',
                'description' => $theme_color['description'], 'pyme',
                'section' => 'sec_color',
                'settings' => $theme_color['slug']
            )
        )
    );
}
