jQuery(document).ready(function () {
    jQuery('#features-section .row .col').addClass("invisible").viewportChecker({
        // Class to add to the elements when they are visible
        classToAdd: 'visible animate__animated animate__zoomIn',

        // The offset of the elements (let them appear earlier or later)
        offset: 1,

        // Add the possibility to remove the class if the elements are not visible
        repeat: true,

        // Callback to do after a class was added to an element. Action will return "add" or "remove", depending if the class was added or removed
        callbackFunction: function (elem, action) { }
    });

    jQuery('#popular-products-section .woocommerce ul li.product').addClass("invisible").viewportChecker({
        // Class to add to the elements when they are visible
        classToAdd: 'visible animate__animated animate__fadeInRight',

        // The offset of the elements (let them appear earlier or later)
        offset: 1,

        // Add the possibility to remove the class if the elements are not visible
        repeat: true,

        // Callback to do after a class was added to an element. Action will return "add" or "remove", depending if the class was added or removed
        callbackFunction: function (elem, action) { }
    });

    jQuery('#about-section .card .description').addClass("invisible").viewportChecker({
        // Class to add to the elements when they are visible
        classToAdd: 'visible animate__animated animate__pulse',

        // The offset of the elements (let them appear earlier or later)
        offset: 1,

        // Add the possibility to remove the class if the elements are not visible
        repeat: true,

        // Callback to do after a class was added to an element. Action will return "add" or "remove", depending if the class was added or removed
        callbackFunction: function (elem, action) { }
    });

    jQuery('#categories-section .row .col').addClass("invisible").viewportChecker({
        // Class to add to the elements when they are visible
        classToAdd: 'visible animate__animated animate__zoomIn',

        // The offset of the elements (let them appear earlier or later)
        offset: 1,

        // Add the possibility to remove the class if the elements are not visible
        repeat: true,

        // Callback to do after a class was added to an element. Action will return "add" or "remove", depending if the class was added or removed
        callbackFunction: function (elem, action) { }
    });

    jQuery('#recent-posts-section .card .row .card').addClass("invisible").viewportChecker({
        // Class to add to the elements when they are visible
        classToAdd: 'visible animate__animated animate__pulse',

        // The offset of the elements (let them appear earlier or later)
        offset: 1,

        // Add the possibility to remove the class if the elements are not visible
        repeat: true,

        // Callback to do after a class was added to an element. Action will return "add" or "remove", depending if the class was added or removed
        callbackFunction: function (elem, action) { }
    });

    jQuery('.posts-list .row article').addClass("invisible").viewportChecker({
        // Class to add to the elements when they are visible
        classToAdd: 'visible animate__animated animate__slideInUp',

        // The offset of the elements (let them appear earlier or later)
        offset: 1,

        // Add the possibility to remove the class if the elements are not visible
        repeat: false,

        // Callback to do after a class was added to an element. Action will return "add" or "remove", depending if the class was added or removed
        callbackFunction: function (elem, action) { }
    });

    jQuery('#about-products-section img').addClass("invisible").viewportChecker({
        // Class to add to the elements when they are visible
        classToAdd: 'visible animate__animated animate__zoomIn',

        // The offset of the elements (let them appear earlier or later)
        offset: 1,

        // Add the possibility to remove the class if the elements are not visible
        repeat: true,

        // Callback to do after a class was added to an element. Action will return "add" or "remove", depending if the class was added or removed
        callbackFunction: function (elem, action) { }
    });

    jQuery('#main-carousel-section #carousel1 .btn').hover(
        function() {
            jQuery(this).addClass("animate__animated animate__headShake");
        },
        function() {
            jQuery(this).removeClass("animate__animated animate__headShake");
        }
    );

    jQuery('.social-media-card svg').hover(
        function() {
            jQuery(this).addClass("animate__animated animate__headShake");
        },
        function() {
            jQuery(this).removeClass("animate__animated animate__headShake");
        }
    );

});

